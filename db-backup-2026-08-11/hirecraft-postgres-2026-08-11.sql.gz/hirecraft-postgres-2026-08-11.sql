--
-- PostgreSQL database cluster dump
--

\restrict 8fi37k4h83xQW0Y0p6OwFAmHrUSNDRul5SiQqwRdKZcWNyi2EwgiLHjl8uu0T2T

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE hirecraft;
ALTER ROLE hirecraft WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:91lXvqoF970r3TgEnYOxTA==$+vJXY0tkEbfegqs5h6+Ju+nxhCjTtIuKEQbi9398wEE=:lZJOzDSttIZ8qe3F+KFrQE7kfdnS/wfPxGfysMXy3To=';

--
-- User Configurations
--








\unrestrict 8fi37k4h83xQW0Y0p6OwFAmHrUSNDRul5SiQqwRdKZcWNyi2EwgiLHjl8uu0T2T

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict pQCKjM8wIrlmqG2kjGV1Awf7oTTitz9YyGdYVNzlqEqv6VTbZLeTrbWYWK9ChX7

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict pQCKjM8wIrlmqG2kjGV1Awf7oTTitz9YyGdYVNzlqEqv6VTbZLeTrbWYWK9ChX7

--
-- Database "hirecraft" dump
--

--
-- PostgreSQL database dump
--

\restrict msrQfio6IoRWosJcydSqqyg11i8e5JqlphmXdesBJ7fI2Nat26hW3iervEbX5ik

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hirecraft; Type: DATABASE; Schema: -; Owner: hirecraft
--

CREATE DATABASE hirecraft WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE hirecraft OWNER TO hirecraft;

\unrestrict msrQfio6IoRWosJcydSqqyg11i8e5JqlphmXdesBJ7fI2Nat26hW3iervEbX5ik
\connect hirecraft
\restrict msrQfio6IoRWosJcydSqqyg11i8e5JqlphmXdesBJ7fI2Nat26hW3iervEbX5ik

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO hirecraft;

--
-- Name: application_artifacts; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.application_artifacts (
    id uuid NOT NULL,
    application_id uuid NOT NULL,
    kind character varying(24) NOT NULL,
    storage_path text NOT NULL,
    size_bytes integer NOT NULL,
    content_type character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.application_artifacts OWNER TO hirecraft;

--
-- Name: applications; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.applications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    job_id uuid NOT NULL,
    resume_profile_id uuid NOT NULL,
    pipeline_status character varying(20) NOT NULL,
    tracker_status character varying(20) NOT NULL,
    celery_task_id character varying(64),
    error_message text,
    tailored_resume jsonb,
    diff jsonb,
    guardrail_report jsonb,
    include_cover_letter boolean NOT NULL,
    notes text,
    total_input_tokens integer NOT NULL,
    total_output_tokens integer NOT NULL,
    total_cost_usd double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    interview_at timestamp with time zone,
    reminder_at timestamp with time zone,
    cost_breakdown jsonb DEFAULT '{}'::jsonb NOT NULL,
    cover_letter jsonb,
    reach_mode boolean DEFAULT false NOT NULL,
    prev_scores jsonb,
    activity jsonb DEFAULT '[]'::jsonb NOT NULL,
    note_entries jsonb DEFAULT '[]'::jsonb NOT NULL
);


ALTER TABLE public.applications OWNER TO hirecraft;

--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.auth_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    purpose character varying(20) NOT NULL,
    payload character varying(320),
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.auth_tokens OWNER TO hirecraft;

--
-- Name: career_profiles; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.career_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    headline character varying(200),
    phone character varying(40),
    location character varying(180),
    linkedin_url character varying(500),
    github_url character varying(500),
    portfolio_url character varying(500),
    website_url character varying(500),
    work_authorization character varying(120),
    visa_status character varying(120),
    years_experience numeric(4,1),
    preferred_roles jsonb NOT NULL,
    preferred_industries jsonb NOT NULL,
    preferred_locations jsonb NOT NULL,
    salary_min integer,
    salary_max integer,
    salary_currency character varying(3) NOT NULL,
    work_arrangement character varying(20),
    open_to_relocation boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    salary_period character varying(12)
);


ALTER TABLE public.career_profiles OWNER TO hirecraft;

--
-- Name: evidence_items; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.evidence_items (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind character varying(16) DEFAULT 'impact'::character varying NOT NULL,
    text text NOT NULL,
    label character varying(160),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.evidence_items OWNER TO hirecraft;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.feature_flags (
    key character varying(60) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feature_flags OWNER TO hirecraft;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    url text,
    source character varying(80),
    title character varying(255),
    company character varying(255),
    location character varying(255),
    raw_text text NOT NULL,
    requirements jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.jobs OWNER TO hirecraft;

--
-- Name: llm_usage; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.llm_usage (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    application_id uuid,
    purpose character varying(64) NOT NULL,
    model character varying(120) NOT NULL,
    input_tokens integer NOT NULL,
    output_tokens integer NOT NULL,
    cost_usd double precision NOT NULL,
    latency_ms integer NOT NULL,
    succeeded boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.llm_usage OWNER TO hirecraft;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    body text,
    link character varying(300),
    dedupe_key character varying(120),
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO hirecraft;

--
-- Name: resume_profiles; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.resume_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    content jsonb NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tags jsonb NOT NULL,
    current_version integer NOT NULL,
    template character varying(20) NOT NULL,
    label text,
    one_page boolean DEFAULT true NOT NULL
);


ALTER TABLE public.resume_profiles OWNER TO hirecraft;

--
-- Name: resume_versions; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.resume_versions (
    id uuid NOT NULL,
    resume_profile_id uuid NOT NULL,
    version integer NOT NULL,
    content jsonb NOT NULL,
    label text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.resume_versions OWNER TO hirecraft;

--
-- Name: saved_cover_letters; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.saved_cover_letters (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    application_id uuid,
    resume_profile_id uuid,
    company character varying(255),
    role character varying(255),
    hiring_manager character varying(255),
    tone character varying(32) DEFAULT 'modern'::character varying NOT NULL,
    used_voice boolean DEFAULT false NOT NULL,
    paragraphs jsonb DEFAULT '[]'::jsonb NOT NULL,
    job_text text,
    guardrail_report jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.saved_cover_letters OWNER TO hirecraft;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_hash character varying(64) NOT NULL,
    user_agent character varying(400),
    ip_address character varying(64),
    last_used_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sessions OWNER TO hirecraft;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(320) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(255),
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_verified boolean NOT NULL,
    verified_at timestamp with time zone,
    theme character varying(10) NOT NULL,
    notification_prefs jsonb NOT NULL,
    encrypted_gemini_key character varying(500),
    encrypted_anthropic_key character varying(500),
    encrypted_openai_key character varying(500),
    llm_provider character varying(20) DEFAULT 'gemini'::character varying NOT NULL,
    llm_model character varying(80)
);


ALTER TABLE public.users OWNER TO hirecraft;

--
-- Name: writing_profiles; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.writing_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    voice jsonb,
    analyzed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.writing_profiles OWNER TO hirecraft;

--
-- Name: writing_samples; Type: TABLE; Schema: public; Owner: hirecraft
--

CREATE TABLE public.writing_samples (
    id uuid NOT NULL,
    writing_profile_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    title character varying(200),
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.writing_samples OWNER TO hirecraft;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.alembic_version (version_num) FROM stdin;
a7b8c9d0e1f2
\.


--
-- Data for Name: application_artifacts; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.application_artifacts (id, application_id, kind, storage_path, size_bytes, content_type, created_at, updated_at) FROM stdin;
f6b7da33-98d3-4442-89f8-ae976dd65c1f	96b6bc24-f3c5-498b-92dd-3dc732104005	COVER_LETTER_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/96b6bc24-f3c5-498b-92dd-3dc732104005/cover_letter.pdf	14837	application/pdf	2026-08-06 20:59:40.699167+00	2026-08-09 03:33:50.233434+00
21b72119-5812-4691-825f-c4641a11393f	f77713d6-8e35-45ce-b889-ea350a6f05c4	COVER_LETTER_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/f77713d6-8e35-45ce-b889-ea350a6f05c4/cover_letter.pdf	14006	application/pdf	2026-08-09 03:57:49.386193+00	2026-08-09 03:57:49.386193+00
9776c94d-8617-4959-930a-929703a203b9	f77713d6-8e35-45ce-b889-ea350a6f05c4	COVER_LETTER_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/f77713d6-8e35-45ce-b889-ea350a6f05c4/cover_letter.tex	2667	application/x-tex	2026-08-09 03:57:49.386193+00	2026-08-09 03:57:49.386193+00
279148ed-d942-445e-9f83-6bf083b4ca32	f77713d6-8e35-45ce-b889-ea350a6f05c4	RESUME_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/f77713d6-8e35-45ce-b889-ea350a6f05c4/resume.pdf	37046	application/pdf	2026-08-07 17:18:18.552336+00	2026-08-07 17:18:18.552336+00
2fd2c799-0fb2-455b-b4d2-ef715d9d0b1e	f77713d6-8e35-45ce-b889-ea350a6f05c4	RESUME_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/f77713d6-8e35-45ce-b889-ea350a6f05c4/resume.tex	6780	application/x-tex	2026-08-07 17:18:18.552336+00	2026-08-07 17:18:18.552336+00
ba7dd021-74c7-4188-b570-07f1b6928208	193ff2ff-7bf6-4d15-b4c8-560463842f49	RESUME_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/193ff2ff-7bf6-4d15-b4c8-560463842f49/resume.pdf	37563	application/pdf	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
fe4910c2-2569-4898-8cad-a7239553dee5	193ff2ff-7bf6-4d15-b4c8-560463842f49	RESUME_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/193ff2ff-7bf6-4d15-b4c8-560463842f49/resume.tex	7343	application/x-tex	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
874e292f-7967-4c4b-a1ac-76924c994a72	193ff2ff-7bf6-4d15-b4c8-560463842f49	COVER_LETTER_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/193ff2ff-7bf6-4d15-b4c8-560463842f49/cover_letter.pdf	14363	application/pdf	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
2fe856ee-eee3-4a6b-8943-c3f00df9614e	193ff2ff-7bf6-4d15-b4c8-560463842f49	COVER_LETTER_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/193ff2ff-7bf6-4d15-b4c8-560463842f49/cover_letter.tex	3023	application/x-tex	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
010552fc-cfde-4e03-a06a-2925ca2a0526	96b6bc24-f3c5-498b-92dd-3dc732104005	RESUME_PDF	f769aa0b-a466-4da4-94a7-e0019363a53a/96b6bc24-f3c5-498b-92dd-3dc732104005/resume.pdf	37028	application/pdf	2026-08-06 18:20:15.503471+00	2026-08-08 07:48:12.894431+00
5a7e45d1-de19-4867-9281-189d021dea36	96b6bc24-f3c5-498b-92dd-3dc732104005	RESUME_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/96b6bc24-f3c5-498b-92dd-3dc732104005/resume.tex	6839	application/x-tex	2026-08-06 18:20:15.503471+00	2026-08-08 07:48:12.894431+00
d71b0679-401c-4ca7-a478-100a6a0ecc16	96b6bc24-f3c5-498b-92dd-3dc732104005	COVER_LETTER_TEX	f769aa0b-a466-4da4-94a7-e0019363a53a/96b6bc24-f3c5-498b-92dd-3dc732104005/cover_letter.tex	3725	application/x-tex	2026-08-06 20:59:40.699167+00	2026-08-09 03:33:50.233434+00
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.applications (id, user_id, job_id, resume_profile_id, pipeline_status, tracker_status, celery_task_id, error_message, tailored_resume, diff, guardrail_report, include_cover_letter, notes, total_input_tokens, total_output_tokens, total_cost_usd, created_at, updated_at, interview_at, reminder_at, cost_breakdown, cover_letter, reach_mode, prev_scores, activity, note_entries) FROM stdin;
193ff2ff-7bf6-4d15-b4c8-560463842f49	f769aa0b-a466-4da4-94a7-e0019363a53a	db327ef6-5908-4e2e-8661-7ceef7fef7e2	920c2bf5-3433-418f-bd17-a045aaa925fb	COMPLETED	DRAFT	331b60ba-fb92-4d7f-bc69-b983d41577d7	\N	{"awards": [], "basics": {"name": "Mohammad Hasnain Raza", "email": "razam@usc.edu", "links": [{"url": "https://linkedin.com/in/hasnainraza03", "label": "LinkedIn"}, {"url": "https://github.com/hasnainrazaa03", "label": "GitHub"}, {"url": "https://hasnainrazaa.vercel.app/", "label": "Website"}], "phone": "(213) 994-5086", "github": "https://github.com/hasnainrazaa03", "summary": "Engineered scalable backend infrastructure, high-throughput REST APIs, and transactional data pipelines using Python, Node.js, SQL, and Docker. Proven track record of optimizing latency below 2 seconds for enterprise integration layers and resolving concurrent write operations across distributed systems. Pursuing an MS in Computer Science at USC with coursework focused on Database Systems and Computer Networks.", "website": "https://hasnainrazaa.vercel.app/", "headline": "Backend Software Engineer | Distributed Systems & High-Throughput APIs", "linkedin": "https://linkedin.com/in/hasnainraza03", "location": "Los Angeles, CA"}, "skills": [{"items": ["Python (Advanced)", "JavaScript", "SQL", "C/C++", "Java", "R", "MATLAB"], "category": "Languages"}, {"items": ["Data Pipelines", "ETL"], "category": "Databases & Architecture"}, {"items": ["Docker", "Git", "Model Monitoring", "Tableau"], "category": "Tools & Cloud"}, {"items": ["PyTorch", "TensorFlow", "Hugging Face", "Scikit-learn", "Pandas", "NumPy", "Classification", "Regression", "NLP", "Feature Engineering"], "category": "Machine Learning & Frameworks"}], "projects": [{"id": "c4fa061d7bb2", "url": null, "name": "Project Vimaan – AI V oice Command NLU System", "end_date": "Present", "highlights": ["Engineered an automated data-generation pipeline synthesizing 30,000+ labeled commands for joint intent and slot classification using FLAN-T5 and Pegasus.", "Fine-tuned DistilBERT models to 98% accuracy and implemented INT8 quantization, compressing model size by 4x while preserving classification speed.", "Deployed NLU services into a flight simulator using UDP thread-safe IPC, ensuring real-time response below 500ms without blocking critical execution loops."], "start_date": "2025-09", "description": "NLP/ML Pipeline with X-Plane Integration", "technologies": []}, {"id": "575af85bce7f", "url": null, "name": "USC Ledger – AI-Powered Financial Management Platform", "end_date": "Present", "highlights": ["Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine to ensure 100% consistency across concurrent updates, producing reliable structured data for downstream analytics and modeling.", "Engineered feature processing logic using fixed-precision arithmetic and 800ms debounced writes to handle high-frequency financial events, reducing API load and ensuring stable inputs for real-time inference.", "Integrated LLM-based analytics using the Google Gemini API, designing prompt templates and context summarization to detect spending anomalies and generate structured financial insights from transaction data."], "start_date": "2025-08", "description": "LLM Integration & Data Engineering", "technologies": []}], "education": [{"id": "756a53a95c4a", "gpa": "4.00", "degree": "Master of Science in Computer Science", "honors": [], "end_date": "2027-12", "location": "Los Angeles, CA", "coursework": ["Algorithms", "Database Systems", "Programming System Design", "Computer Networks", "Machine Learning"], "highlights": [], "start_date": "2025-08", "institution": "University of Southern California", "field_of_study": "Computer Science"}, {"id": "893feb75db31", "gpa": "3.86", "degree": "Bachelor of Engineering in Aerospace Engineering", "honors": ["Silver Medalist"], "end_date": "2022-07", "location": "Bengaluru, India", "coursework": ["Engineering Mathematics", "C Programming", "Computational Fluid Dynamics (CFD)", "Scientific Computing"], "highlights": [], "start_date": "2018-08", "institution": "R V College of Engineering", "field_of_study": "Aerospace Engineering"}], "experience": [{"id": "b313a1ac95f3", "title": "Technology Analyst", "company": "Deloitte", "end_date": "2024-11", "location": "Bengaluru, India", "highlights": ["Scaled backend operations to achieve a 10x improvement in throughput by automating onboarding with Pega PRPC workflows, executing rule-based routing across 35+ countries for 7,500+ customer creations and 12,500+ modifications.", "Engineered a high-performance REST API orchestration layer linking Pega, Informatica MDM, and downstream SAP systems, holding sub-2s latency and ensuring transactional integrity across distributed enterprise systems.", "Designed LLM-assisted request categorization workflows using few-shot and chain-of-thought prompting, attaining 92% agreement with human annotations via human-feedback loops.", "Constructed automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%."], "start_date": "2022-08", "technologies": []}, {"id": "3553d3cab1a7", "title": "Research Intern", "company": "Defence Research and Development Organisation (DRDO)", "end_date": "2022-08", "location": "Bengaluru, India", "highlights": ["Led a 4-member engineering team automating transient CFD simulations, constructing PyFluent pipelines that processed over 1.2TB of aerodynamic data across diverse release conditions.", "Engineered multivariate regression models from pressure and force coefficients to predict store separation trajectories, using Z-score outlier detection to maintain 99.8% data integrity.", "Developed scalable Python data pipelines for terabyte-scale processing, enabling automated time-series feature extraction and signal validation against sensor data."], "start_date": "2022-01", "technologies": []}, {"id": "961fac53e907", "title": "Founding Engineer", "company": "Prana.ai", "end_date": "2021-12", "location": "Remote", "highlights": ["Built end-to-end data processing pipelines for 5M+ MRI/CT image volumes, executing patch extraction, normalization, and balanced sampling for deep learning models.", "Optimized deep learning inference latency to under 0.8s by deploying depthwise separable 3D CNN architectures for real-time segmentation tasks.", "Developed SO(3)-equivariant CNN models using e3nn, boosting volumetric resolution by 35% over baseline implementations."], "start_date": "2019-09", "technologies": []}], "publications": [], "section_order": ["summary", "education", "experience", "projects", "skills", "certifications", "awards", "publications"], "certifications": [], "schema_version": "1.0"}	[{"after": "Backend Software Engineer | Distributed Systems & High-Throughput APIs", "field": "headline", "label": "Headline", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": "Engineered scalable backend infrastructure, high-throughput REST APIs, and transactional data pipelines using Python, Node.js, SQL, and Docker. Proven track record of optimizing latency below 2 seconds for enterprise integration layers and resolving concurrent write operations across distributed systems. Pursuing an MS in Computer Science at USC with coursework focused on Database Systems and Computer Networks.", "field": "summary", "label": "Summary", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": ["Scaled backend operations to achieve a 10x improvement in throughput by automating onboarding with Pega PRPC workflows, executing rule-based routing across 35+ countries for 7,500+ customer creations and 12,500+ modifications.", "Engineered a high-performance REST API orchestration layer linking Pega, Informatica MDM, and downstream SAP systems, holding sub-2s latency and ensuring transactional integrity across distributed enterprise systems.", "Designed LLM-assisted request categorization workflows using few-shot and chain-of-thought prompting, attaining 92% agreement with human annotations via human-feedback loops.", "Constructed automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%."], "field": "highlights", "label": "Deloitte", "before": ["Improved system throughput by 10x by automating manual onboarding with Pega PRPC workflows, implementing rule-based routing across tax, credit, and legal approval chains for customer creation and modification requests across 35+ countries.", "Built a REST API orchestration layer connecting Pega with Informatica MDM and downstream SAP systems, achieving sub-2s latency and ensuring consistent propagation of validated master records across distributed enterprise systems.", "Built LLM-assisted categorization workflows using few-shot prompting to classify customer data requests, achieving 92% agreement with human annotations through iterative refinement using human feedback.", "Implemented data preprocessing pipelines for LLM-based workflows, including automated quality checks, Z-score based outlier filtering, and PII masking, reducing data preparation effort by 30%."], "change": "modified", "section": "experience", "entry_id": "b313a1ac95f3"}, {"after": ["Led a 4-member engineering team automating transient CFD simulations, constructing PyFluent pipelines that processed over 1.2TB of aerodynamic data across diverse release conditions.", "Engineered multivariate regression models from pressure and force coefficients to predict store separation trajectories, using Z-score outlier detection to maintain 99.8% data integrity.", "Developed scalable Python data pipelines for terabyte-scale processing, enabling automated time-series feature extraction and signal validation against sensor data."], "field": "highlights", "label": "Defence Research and Development Organisation (DRDO)", "before": ["Led a 4-member team to automate transient CFD simulations using PyFluent (k- ω SST, overset mesh), generating 1.2TB+ of aerodynamic data across multiple release conditions for downstream modeling and analysis.", "Engineered feature sets from pressure and force coefficients and applied multi-variate regression to model store separation trajectories, identifying key predictors influencing stability under varying flow conditions.", "Built data preprocessing and post-processing pipelines using Python and MATLAB, including Z-score based outlier filtering and time-series feature extraction, enabling reliable inputs for predictive modeling and downstream validation against sensor data."], "change": "modified", "section": "experience", "entry_id": "3553d3cab1a7"}, {"after": ["Built end-to-end data processing pipelines for 5M+ MRI/CT image volumes, executing patch extraction, normalization, and balanced sampling for deep learning models.", "Optimized deep learning inference latency to under 0.8s by deploying depthwise separable 3D CNN architectures for real-time segmentation tasks.", "Developed SO(3)-equivariant CNN models using e3nn, boosting volumetric resolution by 35% over baseline implementations."], "field": "highlights", "label": "Prana.ai", "before": ["Built end-to-end ML pipelines for 5M+ MRI/CT volumes, including normalization, patch extraction, and class-balanced sampling, enabling efficient training of 3D deep learning models on large-scale medical datasets.", "Designed and trained depthwise separable 3D CNNs for medical image segmentation, achieving < 0.8s inference latency through architecture optimization and efficient model deployment for real-time diagnostic use.", "Developed SO(3)-equivariant CNN-based super-resolution models using the e3nn library, leveraging rotation-equivariant convolutions to improve volumetric image quality by 35% over baseline methods."], "change": "modified", "section": "experience", "entry_id": "961fac53e907"}, {"after": ["Engineered an automated data-generation pipeline synthesizing 30,000+ labeled commands for joint intent and slot classification using FLAN-T5 and Pegasus.", "Fine-tuned DistilBERT models to 98% accuracy and implemented INT8 quantization, compressing model size by 4x while preserving classification speed.", "Deployed NLU services into a flight simulator using UDP thread-safe IPC, ensuring real-time response below 500ms without blocking critical execution loops."], "field": "highlights", "label": "Project Vimaan – AI V oice Command NLU System", "before": ["Built a data-generation pipeline producing 30,000+ labeled voice commands for joint intent and slot classification, using schema-driven templates and LLM-based paraphrasing (Pegasus, FLAN-T5) to improve linguistic diversity and label consistency.", "Fine-tuned a DistilBERT model for joint intent classification and entity extraction, optimizing hyperparameters and label design, and applied INT8 quantization to reduce model size by 4x while maintaining 98% accuracy.", "Deployed the model within the X-Plane simulator using a plugin-based architecture with UDP-based IPC, enabling real-time inference with sub-500ms latency and integrating TTS feedback for closed-loop command validation."], "change": "modified", "section": "projects", "entry_id": "c4fa061d7bb2"}, {"after": null, "field": "items", "label": "Skills no longer shown", "before": ["A WS", "BERT", "Evaluation", "Experimentation", "Hyperparameter Tuning", "LLM Fine-tuning", "Model Quantization", "Model Training", "Prompt Engineering", "Statistical Analysis", "T5", "Transformer Models"], "change": "removed", "section": "skills", "entry_id": null}, {"after": ["Languages (7)", "Databases & Architecture (2)", "Tools & Cloud (4)", "Machine Learning & Frameworks (10)"], "field": "groups", "label": "Skill groups", "before": ["Languages (7)", "Machine Learning (7)", "F rameworks (6)", "Data & Systems (4)", "LLM & NLP (5)", "T ools (6)"], "change": "reordered", "section": "skills", "entry_id": null}]	{"locks": ["Employers & job titles", "Employment dates", "Schools, degrees & GPA", "Project names", "Contact details", "Awards, certifications & publications"], "violations": [{"kind": "fabricated_proper_noun", "field": "headline", "action": "flagged", "detail": "headline: mentions High-Throughput, absent from your master resume.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "summary", "action": "flagged", "detail": "summary: mentions Proven, absent from your master resume.", "entry_id": null, "severity": "warning"}, {"kind": "unknown_entry_id", "field": null, "action": "rejected", "detail": "Model returned experience entry id '575af85bce7f', which does not exist in the master resume. Discarded.", "entry_id": "575af85bce7f", "severity": "error"}, {"kind": "fabricated_proper_noun", "field": "highlights", "action": "flagged", "detail": "Defence Research and Development Organisation (DRDO): mentions TB, which you never mention in your master resume. Confirm this is true before applying.", "entry_id": "3553d3cab1a7", "severity": "warning"}, {"kind": "bullet_count_inflated", "field": "highlights", "action": "dropped", "detail": "University of Southern California: model returned 1 verified bullets for an entry with 0 in the master. Extra bullets dropped.", "entry_id": "756a53a95c4a", "severity": "warning"}, {"kind": "bullet_count_inflated", "field": "highlights", "action": "dropped", "detail": "R V College of Engineering: model returned 1 verified bullets for an entry with 0 in the master. Extra bullets dropped.", "entry_id": "893feb75db31", "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Databases & Architecture' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "dropped", "detail": "Skill 'AWS' is supported nowhere in your résumé or evidence. Dropped - HireCraft will not claim a skill you have not shown.", "entry_id": null, "severity": "error"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Tools & Cloud' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Machine Learning & Frameworks' was renamed by the model.", "entry_id": null, "severity": "warning"}], "bullet_confidence": [{"text": "Scaled backend operations to achieve a 10x improvement in throughput by automating onboarding with Pega PRPC workflows, executing rule-based routing across 35+ countries for 7,500+ customer creations and 12,500+ modifications.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Engineered a high-performance REST API orchestration layer linking Pega, Informatica MDM, and downstream SAP systems, holding sub-2s latency and ensuring transactional integrity across distributed enterprise systems.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Designed LLM-assisted request categorization workflows using few-shot and chain-of-thought prompting, attaining 92% agreement with human annotations via human-feedback loops.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Constructed automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Led a 4-member engineering team automating transient CFD simulations, constructing PyFluent pipelines that processed over 1.2TB of aerodynamic data across diverse release conditions.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Mentions TB, not found in your résumé.", "entry_id": "3553d3cab1a7", "confidence": "needs_review"}, {"text": "Engineered multivariate regression models from pressure and force coefficients to predict store separation trajectories, using Z-score outlier detection to maintain 99.8% data integrity.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Developed scalable Python data pipelines for terabyte-scale processing, enabling automated time-series feature extraction and signal validation against sensor data.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Built end-to-end data processing pipelines for 5M+ MRI/CT image volumes, executing patch extraction, normalization, and balanced sampling for deep learning models.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Optimized deep learning inference latency to under 0.8s by deploying depthwise separable 3D CNN architectures for real-time segmentation tasks.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Developed SO(3)-equivariant CNN models using e3nn, boosting volumetric resolution by 35% over baseline implementations.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Engineered an automated data-generation pipeline synthesizing 30,000+ labeled commands for joint intent and slot classification using FLAN-T5 and Pegasus.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Fine-tuned DistilBERT models to 98% accuracy and implemented INT8 quantization, compressing model size by 4x while preserving classification speed.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Deployed NLU services into a flight simulator using UDP thread-safe IPC, ensuring real-time response below 500ms without blocking critical execution loops.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Maintained a 4.00 GPA with rigorous graduate coursework in Database Systems, Computer Networks, Algorithms, Programming System Design, and Machine Learning.", "label": "University of Southern California", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "756a53a95c4a", "confidence": "likely"}, {"text": "Graduated with a 3.86 GPA and awarded the Silver Medal for academic excellence; coursework included C Programming, Computational Fluid Dynamics, and Scientific Computing.", "label": "R V College of Engineering", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "893feb75db31", "confidence": "likely"}, {"text": "Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine to ensure 100% consistency across concurrent updates, producing reliable structured data for downstream analytics and modeling.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Unchanged from your résumé.", "entry_id": "575af85bce7f", "confidence": "verified"}, {"text": "Engineered feature processing logic using fixed-precision arithmetic and 800ms debounced writes to handle high-frequency financial events, reducing API load and ensuring stable inputs for real-time inference.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Unchanged from your résumé.", "entry_id": "575af85bce7f", "confidence": "verified"}, {"text": "Integrated LLM-based analytics using the Google Gemini API, designing prompt templates and context summarization to detect spending anomalies and generate structured financial insights from transaction data.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Unchanged from your résumé.", "entry_id": "575af85bce7f", "confidence": "verified"}], "keywords_verified": ["Python", "Node.js", "REST APIs", "distributed systems", "MongoDB", "SQL", "Docker"], "keywords_requested": ["Python", "Node.js", "RESTful APIs", "REST APIs", "distributed systems", "PostgreSQL", "MongoDB", "SQL", "NoSQL", "Docker", "AWS", "GCP", "Azure", "Microservices", "Kafka", "RabbitMQ", "Kubernetes", "CI/CD", "Event-driven architectures", "CI/CD pipelines", "Performance optimization"]}	t	\N	12146	3126	0.002464	2026-08-08 03:13:45.056879+00	2026-08-08 03:44:07.734905+00	\N	\N	{"resume": {"cost_usd": 0.001422, "input_tokens": 6467, "output_tokens": 1939}, "cover_letter": {"cost_usd": 0.001042, "input_tokens": 5679, "output_tokens": 1187}}	\N	f	\N	[]	[]
f77713d6-8e35-45ce-b889-ea350a6f05c4	f769aa0b-a466-4da4-94a7-e0019363a53a	576bdc10-79c5-43b6-91bd-ad548ccc2eff	920c2bf5-3433-418f-bd17-a045aaa925fb	COMPLETED	DRAFT	cbec9415-5317-46b1-bc3c-a05889dcd0a1	\N	{"awards": [], "basics": {"name": "Mohammad Hasnain Raza", "email": "razam@usc.edu", "links": [{"url": "https://linkedin.com/in/hasnainraza03", "label": "LinkedIn"}, {"url": "https://github.com/hasnainrazaa03", "label": "GitHub"}, {"url": "https://hasnainrazaa.vercel.app/", "label": "Website"}], "phone": "(213) 994-5086", "github": "https://github.com/hasnainrazaa03", "summary": "Master of Science in Computer Science candidate with extensive experience building end-to-end NLP pipelines, LLM fine-tuning, and quantized transformer architectures for real-time inference. Proven track record in prompt engineering, high-throughput data processing, and deep learning model deployment.", "website": "https://hasnainrazaa.vercel.app/", "headline": "Machine Learning Engineer | Conversational AI & NLP Specialist", "linkedin": "https://linkedin.com/in/hasnainraza03", "location": "Los Angeles, CA"}, "skills": [{"items": ["LLM Fine-tuning", "Transformer Models", "Prompt Engineering", "BERT", "T5", "NLP"], "category": "LLM & Conversational AI"}, {"items": ["PyTorch", "TensorFlow", "Hugging Face", "Scikit-learn", "Model Quantization", "Feature Engineering", "Classification"], "category": "Machine Learning & Frameworks"}, {"items": ["Python (Advanced)", "C/C++", "Java", "JavaScript", "SQL", "Data Pipelines"], "category": "Languages & Systems"}], "projects": [{"id": "c4fa061d7bb2", "url": null, "name": "Project Vimaan – AI V oice Command NLU System", "end_date": "Present", "highlights": ["Built a data-generation pipeline synthesizing 30,000+ labeled voice commands using LLM paraphrasing (FLAN-T5, Pegasus) for joint intent-and-slot classification.", "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 quantization to compress model size by 4x.", "Deployed NLU models into the X-Plane simulator via thread-safe UDP IPC, achieving sub-500ms real-time inference latency with TTS feedback."], "start_date": "2025-09", "description": "NLP/ML Pipeline with X-Plane Integration", "technologies": []}, {"id": "575af85bce7f", "url": null, "name": "USC Ledger – AI-Powered Financial Management Platform", "end_date": "Present", "highlights": ["Built a transactional data pipeline in Node.js and MongoDB featuring a sequential reconciliation engine to ensure strict consistency across concurrent writes.", "Engineered feature processing logic using precision-first arithmetic and 800ms debouncing to prevent race conditions and optimize server load.", "Integrated Google Gemini LLM behind a structured prompt-engineering layer with context summarization to detect anomalies from transaction data."], "start_date": "2025-08", "description": "LLM Integration & Data Engineering", "technologies": []}], "education": [{"id": "756a53a95c4a", "gpa": "4.00", "degree": "Master of Science in Computer Science", "honors": [], "end_date": "2027-12", "location": "Los Angeles, CA", "coursework": ["Algorithms", "Database Systems", "Programming System Design", "Computer Networks", "Machine Learning"], "highlights": [], "start_date": "2025-08", "institution": "University of Southern California", "field_of_study": "Computer Science"}, {"id": "893feb75db31", "gpa": "3.86", "degree": "Bachelor of Engineering in Aerospace Engineering", "honors": ["Silver Medalist"], "end_date": "2022-07", "location": "Bengaluru, India", "coursework": ["Engineering Mathematics", "C Programming", "Computational Fluid Dynamics (CFD)", "Scientific Computing"], "highlights": [], "start_date": "2018-08", "institution": "R V College of Engineering", "field_of_study": "Aerospace Engineering"}], "experience": [{"id": "b313a1ac95f3", "title": "Technology Analyst", "company": "Deloitte", "end_date": "2024-11", "location": "Bengaluru, India", "highlights": ["Engineered enterprise workflows across 35+ countries, achieving a 10x system throughput increase across 7,500+ creations and 12,500+ modification requests.", "Architected a REST API orchestration layer linking Pega, Informatica MDM, and SAP, maintaining sub-2s latency for distributed master data propagation.", "Developed LLM-assisted categorization pipelines using few-shot and chain-of-thought prompting, reaching 92% agreement with human annotations via iterative feedback loops.", "Constructed automated data preprocessing pipelines with Z-score outlier filtering and PII masking, cutting LLM data preparation effort by 30%."], "start_date": "2022-08", "technologies": []}, {"id": "961fac53e907", "title": "Founding Engineer", "company": "Prana.ai", "end_date": "2021-12", "location": "Remote", "highlights": ["Built end-to-end ML data pipelines for 5M+ MRI/CT volumes, incorporating class-balanced sampling and normalization to train 3D deep learning models.", "Designed and optimized depthwise-separable 3D CNNs for segmentation, reaching sub-0.8s inference latency for real-time diagnostic use.", "Developed SO(3)-equivariant CNN super-resolution models using e3nn, boosting volumetric image quality by 35% over baseline methods."], "start_date": "2019-09", "technologies": []}, {"id": "3553d3cab1a7", "title": "Research Intern", "company": "Defence Research and Development Organisation (DRDO)", "end_date": "2022-08", "location": "Bengaluru, India", "highlights": ["Led a 4-member team automating transient CFD simulations with PyFluent, generating over 1.2TB of aerodynamic data for downstream predictive modeling.", "Engineered multivariate regression models from pressure and force coefficients to predict trajectory stability across diverse flow conditions.", "Built Python and MATLAB pre/post-processing pipelines with Z-score outlier filtering (~99.8% data integrity) and time-series extraction to validate trajectories against sensor data."], "start_date": "2022-01", "technologies": []}], "publications": [], "section_order": ["summary", "education", "experience", "projects", "skills", "certifications", "awards", "publications"], "certifications": [], "schema_version": "1.0"}	[{"after": "Machine Learning Engineer | Conversational AI & NLP Specialist", "field": "headline", "label": "Headline", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": "Master of Science in Computer Science candidate with extensive experience building end-to-end NLP pipelines, LLM fine-tuning, and quantized transformer architectures for real-time inference. Proven track record in prompt engineering, high-throughput data processing, and deep learning model deployment.", "field": "summary", "label": "Summary", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": ["Engineered enterprise workflows across 35+ countries, achieving a 10x system throughput increase across 7,500+ creations and 12,500+ modification requests.", "Architected a REST API orchestration layer linking Pega, Informatica MDM, and SAP, maintaining sub-2s latency for distributed master data propagation.", "Developed LLM-assisted categorization pipelines using few-shot and chain-of-thought prompting, reaching 92% agreement with human annotations via iterative feedback loops.", "Constructed automated data preprocessing pipelines with Z-score outlier filtering and PII masking, cutting LLM data preparation effort by 30%."], "field": "highlights", "label": "Deloitte", "before": ["Improved system throughput by 10x by automating manual onboarding with Pega PRPC workflows, implementing rule-based routing across tax, credit, and legal approval chains for customer creation and modification requests across 35+ countries.", "Built a REST API orchestration layer connecting Pega with Informatica MDM and downstream SAP systems, achieving sub-2s latency and ensuring consistent propagation of validated master records across distributed enterprise systems.", "Built LLM-assisted categorization workflows using few-shot prompting to classify customer data requests, achieving 92% agreement with human annotations through iterative refinement using human feedback.", "Implemented data preprocessing pipelines for LLM-based workflows, including automated quality checks, Z-score based outlier filtering, and PII masking, reducing data preparation effort by 30%."], "change": "modified", "section": "experience", "entry_id": "b313a1ac95f3"}, {"after": ["Led a 4-member team automating transient CFD simulations with PyFluent, generating over 1.2TB of aerodynamic data for downstream predictive modeling.", "Engineered multivariate regression models from pressure and force coefficients to predict trajectory stability across diverse flow conditions.", "Built Python and MATLAB pre/post-processing pipelines with Z-score outlier filtering (~99.8% data integrity) and time-series extraction to validate trajectories against sensor data."], "field": "highlights", "label": "Defence Research and Development Organisation (DRDO)", "before": ["Led a 4-member team to automate transient CFD simulations using PyFluent (k- ω SST, overset mesh), generating 1.2TB+ of aerodynamic data across multiple release conditions for downstream modeling and analysis.", "Engineered feature sets from pressure and force coefficients and applied multi-variate regression to model store separation trajectories, identifying key predictors influencing stability under varying flow conditions.", "Built data preprocessing and post-processing pipelines using Python and MATLAB, including Z-score based outlier filtering and time-series feature extraction, enabling reliable inputs for predictive modeling and downstream validation against sensor data."], "change": "modified", "section": "experience", "entry_id": "3553d3cab1a7"}, {"after": ["Built end-to-end ML data pipelines for 5M+ MRI/CT volumes, incorporating class-balanced sampling and normalization to train 3D deep learning models.", "Designed and optimized depthwise-separable 3D CNNs for segmentation, reaching sub-0.8s inference latency for real-time diagnostic use.", "Developed SO(3)-equivariant CNN super-resolution models using e3nn, boosting volumetric image quality by 35% over baseline methods."], "field": "highlights", "label": "Prana.ai", "before": ["Built end-to-end ML pipelines for 5M+ MRI/CT volumes, including normalization, patch extraction, and class-balanced sampling, enabling efficient training of 3D deep learning models on large-scale medical datasets.", "Designed and trained depthwise separable 3D CNNs for medical image segmentation, achieving < 0.8s inference latency through architecture optimization and efficient model deployment for real-time diagnostic use.", "Developed SO(3)-equivariant CNN-based super-resolution models using the e3nn library, leveraging rotation-equivariant convolutions to improve volumetric image quality by 35% over baseline methods."], "change": "modified", "section": "experience", "entry_id": "961fac53e907"}, {"after": ["b313a1ac95f3", "961fac53e907", "3553d3cab1a7"], "field": "order", "label": "Experience order", "before": ["b313a1ac95f3", "3553d3cab1a7", "961fac53e907"], "change": "reordered", "section": "experience", "entry_id": null}, {"after": ["Built a data-generation pipeline synthesizing 30,000+ labeled voice commands using LLM paraphrasing (FLAN-T5, Pegasus) for joint intent-and-slot classification.", "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 quantization to compress model size by 4x.", "Deployed NLU models into the X-Plane simulator via thread-safe UDP IPC, achieving sub-500ms real-time inference latency with TTS feedback."], "field": "highlights", "label": "Project Vimaan – AI V oice Command NLU System", "before": ["Built a data-generation pipeline producing 30,000+ labeled voice commands for joint intent and slot classification, using schema-driven templates and LLM-based paraphrasing (Pegasus, FLAN-T5) to improve linguistic diversity and label consistency.", "Fine-tuned a DistilBERT model for joint intent classification and entity extraction, optimizing hyperparameters and label design, and applied INT8 quantization to reduce model size by 4x while maintaining 98% accuracy.", "Deployed the model within the X-Plane simulator using a plugin-based architecture with UDP-based IPC, enabling real-time inference with sub-500ms latency and integrating TTS feedback for closed-loop command validation."], "change": "modified", "section": "projects", "entry_id": "c4fa061d7bb2"}, {"after": ["Built a transactional data pipeline in Node.js and MongoDB featuring a sequential reconciliation engine to ensure strict consistency across concurrent writes.", "Engineered feature processing logic using precision-first arithmetic and 800ms debouncing to prevent race conditions and optimize server load.", "Integrated Google Gemini LLM behind a structured prompt-engineering layer with context summarization to detect anomalies from transaction data."], "field": "highlights", "label": "USC Ledger – AI-Powered Financial Management Platform", "before": ["Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine to ensure 100% consistency across concurrent updates, producing reliable structured data for downstream analytics and modeling.", "Engineered feature processing logic using fixed-precision arithmetic and 800ms debounced writes to handle high-frequency financial events, reducing API load and ensuring stable inputs for real-time inference.", "Integrated LLM-based analytics using the Google Gemini API, designing prompt templates and context summarization to detect spending anomalies and generate structured financial insights from transaction data."], "change": "modified", "section": "projects", "entry_id": "575af85bce7f"}, {"after": null, "field": "items", "label": "Skills no longer shown", "before": ["A WS", "Docker", "ETL", "Evaluation", "Experimentation", "Git", "Hyperparameter Tuning", "MATLAB", "Model Monitoring", "Model Training", "NumPy", "Pandas", "R", "Regression", "Statistical Analysis", "Tableau"], "change": "removed", "section": "skills", "entry_id": null}, {"after": ["LLM & Conversational AI (6)", "Machine Learning & Frameworks (7)", "Languages & Systems (6)"], "field": "groups", "label": "Skill groups", "before": ["Languages (7)", "Machine Learning (7)", "F rameworks (6)", "Data & Systems (4)", "LLM & NLP (5)", "T ools (6)"], "change": "reordered", "section": "skills", "entry_id": null}]	{"locks": ["Employers & job titles", "Employment dates", "Schools, degrees & GPA", "Project names", "Contact details", "Awards, certifications & publications"], "violations": [{"kind": "fabricated_proper_noun", "field": "headline", "action": "flagged", "detail": "headline: mentions Conversational, Specialist, absent from your master resume.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "summary", "action": "flagged", "detail": "summary: mentions Proven, absent from your master resume.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "highlights", "action": "flagged", "detail": "Defence Research and Development Organisation (DRDO): mentions TB, which you never mention in your master resume. Confirm this is true before applying.", "entry_id": "3553d3cab1a7", "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "highlights", "action": "flagged", "detail": "Prana.ai: mentions sub-0.8s, which you never mention in your master resume. Confirm this is true before applying.", "entry_id": "961fac53e907", "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'LLM & Conversational AI' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Machine Learning & Frameworks' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Languages & Systems' was renamed by the model.", "entry_id": null, "severity": "warning"}], "bullet_confidence": [{"text": "Engineered enterprise workflows across 35+ countries, achieving a 10x system throughput increase across 7,500+ creations and 12,500+ modification requests.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Architected a REST API orchestration layer linking Pega, Informatica MDM, and SAP, maintaining sub-2s latency for distributed master data propagation.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Developed LLM-assisted categorization pipelines using few-shot and chain-of-thought prompting, reaching 92% agreement with human annotations via iterative feedback loops.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Constructed automated data preprocessing pipelines with Z-score outlier filtering and PII masking, cutting LLM data preparation effort by 30%.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Led a 4-member team automating transient CFD simulations with PyFluent, generating over 1.2TB of aerodynamic data for downstream predictive modeling.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Mentions TB, not found in your résumé.", "entry_id": "3553d3cab1a7", "confidence": "needs_review"}, {"text": "Engineered multivariate regression models from pressure and force coefficients to predict trajectory stability across diverse flow conditions.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Built Python and MATLAB pre/post-processing pipelines with Z-score outlier filtering (~99.8% data integrity) and time-series extraction to validate trajectories against sensor data.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Built end-to-end ML data pipelines for 5M+ MRI/CT volumes, incorporating class-balanced sampling and normalization to train 3D deep learning models.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Designed and optimized depthwise-separable 3D CNNs for segmentation, reaching sub-0.8s inference latency for real-time diagnostic use.", "label": "Prana.ai", "reason": "Mentions sub-0.8s, not found in your résumé.", "entry_id": "961fac53e907", "confidence": "needs_review"}, {"text": "Developed SO(3)-equivariant CNN super-resolution models using e3nn, boosting volumetric image quality by 35% over baseline methods.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Built a data-generation pipeline synthesizing 30,000+ labeled voice commands using LLM paraphrasing (FLAN-T5, Pegasus) for joint intent-and-slot classification.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 quantization to compress model size by 4x.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Deployed NLU models into the X-Plane simulator via thread-safe UDP IPC, achieving sub-500ms real-time inference latency with TTS feedback.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Built a transactional data pipeline in Node.js and MongoDB featuring a sequential reconciliation engine to ensure strict consistency across concurrent writes.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "575af85bce7f", "confidence": "likely"}, {"text": "Engineered feature processing logic using precision-first arithmetic and 800ms debouncing to prevent race conditions and optimize server load.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "575af85bce7f", "confidence": "likely"}, {"text": "Integrated Google Gemini LLM behind a structured prompt-engineering layer with context summarization to detect anomalies from transaction data.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "575af85bce7f", "confidence": "likely"}], "keywords_verified": [], "keywords_requested": []}	t	\N	11137	1808	0.001837	2026-08-07 17:17:57.251666+00	2026-08-09 03:57:49.386193+00	\N	\N	{"resume": {"cost_usd": 0.001044, "input_tokens": 5119, "output_tokens": 1331}, "cover_letter": {"cost_usd": 0.000793, "input_tokens": 6018, "output_tokens": 477}}	["Developing conversational AI systems for TikTok E-Commerce requires robust intent parsing, efficient model deployment, and scalable data processing to power real-time interactions. As a Machine Learning Engineer Graduate candidate at ByteDance, I bring direct experience building real-time NLU pipelines and enterprise-scale data systems. In my Project Vimaan initiative, I built an end-to-end NLU system that fine-tuned DistilBERT for joint intent and slot classification across 30,000+ synthesized voice commands, utilizing INT8 quantization to cut model size 4x while maintaining sub-500ms latency for live interaction.", "To address ByteDance's focus on advanced NLP and conversational interactions, I offer extensive experience in LLM pipelines and prompt engineering. At Deloitte, I engineered LLM-assisted request categorization workflows using few-shot and chain-of-thought prompting alongside RLHF-style human feedback loops, achieving a 92% agreement rate with human annotations. Additionally, I built automated data-preprocessing pipelines with quality checks and Z-score outlier filtering, reducing data preparation overhead by 30% and ensuring clean inputs for complex language models.", "ByteDance's mission to inspire creativity and enrich life through TikTok E-Commerce aligns with my background in deploying low-latency NLP models, optimized data pipelines, and scalable enterprise architectures. Holding a 4.0 GPA in my Master's in Computer Science at USC, I am eager to apply my research and engineering experience to solve complex conversational AI challenges for your global e-commerce platform."]	f	\N	[{"at": "2026-08-09T02:09:00.912598+00:00", "kind": "status_changed", "meta": {"to": "applied", "from": "preparing"}, "label": "Status → Applied"}, {"at": "2026-08-09T03:57:54.288601+00:00", "kind": "cover_letter", "meta": {}, "label": "Cover letter generated"}]	[]
96b6bc24-f3c5-498b-92dd-3dc732104005	f769aa0b-a466-4da4-94a7-e0019363a53a	6f1390fd-5c2f-4098-8faa-94acf6adefbf	920c2bf5-3433-418f-bd17-a045aaa925fb	COMPLETED	APPLIED	0394aa1d-4e62-4b1a-a0dd-932bbaa62e41	\N	{"awards": [], "basics": {"name": "Mohammad Hasnain Raza", "email": "razam@usc.edu", "links": [{"url": "https://linkedin.com/in/hasnainraza03", "label": "LinkedIn"}, {"url": "https://github.com/hasnainrazaa03", "label": "GitHub"}, {"url": "https://hasnainrazaa.vercel.app/", "label": "Website"}], "phone": "(213) 994-5086", "github": "https://github.com/hasnainrazaa03", "summary": "Machine Learning Engineer specializing in PyTorch, TensorFlow, LLM fine-tuning, transformer models, and model quantization. track record deploying production ML data pipelines, optimizing sub-second inference latency, and fine-tuning NLP networks. Holds a 4.0 GPA MS in Computer Science from USC.", "website": "https://hasnainrazaa.vercel.app/", "headline": "Machine Learning Engineer | MS at USC (4.0 GPA)", "linkedin": "https://linkedin.com/in/hasnainraza03", "location": "Los Angeles, CA"}, "skills": [{"items": ["Python (Advanced)", "C/C++", "Java", "JavaScript", "SQL", "MATLAB", "R"], "category": "Languages"}, {"items": ["Model Training", "Model Quantization", "LLM Fine-tuning", "Feature Engineering", "Classification", "Regression", "Model Monitoring"], "category": "Machine Learning & AI"}, {"items": ["PyTorch", "TensorFlow", "Hugging Face", "Scikit-learn", "Transformer Models", "BERT", "T5"], "category": "Frameworks & Libraries"}, {"items": ["Data Pipelines", "ETL", "NumPy", "Pandas", "Prompt Engineering", "Docker", "Git"], "category": "Data & Engineering"}], "projects": [{"id": "c4fa061d7bb2", "url": null, "name": "Project Vimaan – AI V oice Command NLU System", "end_date": "Present", "highlights": ["Constructed a synthetic data-generation pipeline outputting 30,000+ labeled voice commands using schema-driven templates and LLM paraphrasing (FLAN-T5).", "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 model quantization to cut model footprint 4x.", "Integrated real-time NLU inference into the X-Plane simulator via UDP IPC and plugin architecture, sustaining sub-500ms latency without interrupting execution loops."], "start_date": "2025-09", "description": "NLP/ML Pipeline with X-Plane Integration", "technologies": []}, {"id": "575af85bce7f", "url": null, "name": "USC Ledger – AI-Powered Financial Management Platform", "end_date": "Present", "highlights": ["Architected a high-concurrency transactional data pipeline using Node.js and MongoDB with sequential reconciliation to eliminate 100% of concurrent write conflicts.", "Integrated Google Gemini LLM API using structured prompt engineering and context summarization to automate real-time financial anomaly detection and accelerate risk identification."], "start_date": "2025-08", "description": "LLM Integration & Data Engineering", "technologies": []}], "education": [{"id": "756a53a95c4a", "gpa": "4.00", "degree": "Master of Science in Computer Science", "honors": [], "end_date": "2027-12", "location": "Los Angeles, CA", "coursework": ["Algorithms", "Database Systems", "Programming System Design", "Computer Networks", "Machine Learning"], "highlights": [], "start_date": "2025-08", "institution": "University of Southern California", "field_of_study": "Computer Science"}, {"id": "893feb75db31", "gpa": "3.86", "degree": "Bachelor of Engineering in Aerospace Engineering", "honors": ["Silver Medalist"], "end_date": "2022-07", "location": "Bengaluru, India", "coursework": ["Engineering Mathematics", "C Programming", "Computational Fluid Dynamics (CFD)", "Scientific Computing"], "highlights": [], "start_date": "2018-08", "institution": "R V College of Engineering", "field_of_study": "Aerospace Engineering"}], "experience": [{"id": "b313a1ac95f3", "title": "Technology Analyst", "company": "Deloitte", "end_date": "2024-11", "location": "Bengaluru, India", "highlights": ["Boosted core system throughput 10x by automating customer onboarding via rule-based Pega PRPC workflows across tax, credit, and legal chains across 35+ countries.", "Engineered a sub-2s latency REST API orchestration layer linking Pega with Informatica MDM and SAP to ensure consistent propagation of master records.", "Created LLM-driven categorization workflows with few-shot prompting, achieving 92% human annotation agreement via iterative feedback loops.", "Built automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%."], "start_date": "2022-08", "technologies": []}, {"id": "3553d3cab1a7", "title": "Research Intern", "company": "Defence Research and Development Organisation (DRDO)", "end_date": "2022-08", "location": "Bengaluru, India", "highlights": ["Directed a 4-member engineering team to automate transient CFD simulations in PyFluent (k-omega SST, overset mesh), producing 1.2TB+ of aerodynamic data.", "Extracted feature sets from pressure and force coefficients using multi-variate regression to model store-separation trajectories with ~99.8% data integrity.", "Developed Python and MATLAB data pipelines featuring Z-score outlier filtering and time-series feature extraction to validate sensor models across 1.2TB+ of dataset runs."], "start_date": "2022-01", "technologies": []}, {"id": "961fac53e907", "title": "Founding Engineer", "company": "Prana.ai", "end_date": "2021-12", "location": "Remote", "highlights": ["Engineered end-to-end ML data pipelines for 5M+ MRI/CT volumes using normalization, patch extraction, and class-balanced sampling to power production deep learning models.", "Architected depthwise separable 3D CNNs for medical image segmentation, optimizing real-time inference latency under 0.8s for diagnostic deployment.", "Designed SO(3)-equivariant CNN super-resolution models (e3nn) using rotation-equivariant convolutions, elevating volumetric image quality by 35% over baselines."], "start_date": "2019-09", "technologies": []}], "publications": [], "section_order": ["summary", "education", "experience", "projects", "skills", "certifications", "awards", "publications"], "certifications": [], "schema_version": "1.0"}	[{"after": "Machine Learning Engineer | MS at USC (4.0 GPA)", "field": "headline", "label": "Headline", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": "Machine Learning Engineer specializing in PyTorch, TensorFlow, LLM fine-tuning, transformer models, and model quantization. track record deploying production ML data pipelines, optimizing sub-second inference latency, and fine-tuning NLP networks. Holds a 4.0 GPA MS in Computer Science from USC.", "field": "summary", "label": "Summary", "before": null, "change": "added", "section": "basics", "entry_id": null}, {"after": ["Boosted core system throughput 10x by automating customer onboarding via rule-based Pega PRPC workflows across tax, credit, and legal chains across 35+ countries.", "Engineered a sub-2s latency REST API orchestration layer linking Pega with Informatica MDM and SAP to ensure consistent propagation of master records.", "Created LLM-driven categorization workflows with few-shot prompting, achieving 92% human annotation agreement via iterative feedback loops.", "Built automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%."], "field": "highlights", "label": "Deloitte", "before": ["Improved system throughput by 10x by automating manual onboarding with Pega PRPC workflows, implementing rule-based routing across tax, credit, and legal approval chains for customer creation and modification requests across 35+ countries.", "Built a REST API orchestration layer connecting Pega with Informatica MDM and downstream SAP systems, achieving sub-2s latency and ensuring consistent propagation of validated master records across distributed enterprise systems.", "Built LLM-assisted categorization workflows using few-shot prompting to classify customer data requests, achieving 92% agreement with human annotations through iterative refinement using human feedback.", "Implemented data preprocessing pipelines for LLM-based workflows, including automated quality checks, Z-score based outlier filtering, and PII masking, reducing data preparation effort by 30%."], "change": "modified", "section": "experience", "entry_id": "b313a1ac95f3"}, {"after": ["Directed a 4-member engineering team to automate transient CFD simulations in PyFluent (k-omega SST, overset mesh), producing 1.2TB+ of aerodynamic data.", "Extracted feature sets from pressure and force coefficients using multi-variate regression to model store-separation trajectories with ~99.8% data integrity.", "Developed Python and MATLAB data pipelines featuring Z-score outlier filtering and time-series feature extraction to validate sensor models across 1.2TB+ of dataset runs."], "field": "highlights", "label": "Defence Research and Development Organisation (DRDO)", "before": ["Led a 4-member team to automate transient CFD simulations using PyFluent (k- ω SST, overset mesh), generating 1.2TB+ of aerodynamic data across multiple release conditions for downstream modeling and analysis.", "Engineered feature sets from pressure and force coefficients and applied multi-variate regression to model store separation trajectories, identifying key predictors influencing stability under varying flow conditions.", "Built data preprocessing and post-processing pipelines using Python and MATLAB, including Z-score based outlier filtering and time-series feature extraction, enabling reliable inputs for predictive modeling and downstream validation against sensor data."], "change": "modified", "section": "experience", "entry_id": "3553d3cab1a7"}, {"after": ["Engineered end-to-end ML data pipelines for 5M+ MRI/CT volumes using normalization, patch extraction, and class-balanced sampling to power production deep learning models.", "Architected depthwise separable 3D CNNs for medical image segmentation, optimizing real-time inference latency under 0.8s for diagnostic deployment.", "Designed SO(3)-equivariant CNN super-resolution models (e3nn) using rotation-equivariant convolutions, elevating volumetric image quality by 35% over baselines."], "field": "highlights", "label": "Prana.ai", "before": ["Built end-to-end ML pipelines for 5M+ MRI/CT volumes, including normalization, patch extraction, and class-balanced sampling, enabling efficient training of 3D deep learning models on large-scale medical datasets.", "Designed and trained depthwise separable 3D CNNs for medical image segmentation, achieving < 0.8s inference latency through architecture optimization and efficient model deployment for real-time diagnostic use.", "Developed SO(3)-equivariant CNN-based super-resolution models using the e3nn library, leveraging rotation-equivariant convolutions to improve volumetric image quality by 35% over baseline methods."], "change": "modified", "section": "experience", "entry_id": "961fac53e907"}, {"after": ["Constructed a synthetic data-generation pipeline outputting 30,000+ labeled voice commands using schema-driven templates and LLM paraphrasing (FLAN-T5).", "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 model quantization to cut model footprint 4x.", "Integrated real-time NLU inference into the X-Plane simulator via UDP IPC and plugin architecture, sustaining sub-500ms latency without interrupting execution loops."], "field": "highlights", "label": "Project Vimaan – AI V oice Command NLU System", "before": ["Built a data-generation pipeline producing 30,000+ labeled voice commands for joint intent and slot classification, using schema-driven templates and LLM-based paraphrasing (Pegasus, FLAN-T5) to improve linguistic diversity and label consistency.", "Fine-tuned a DistilBERT model for joint intent classification and entity extraction, optimizing hyperparameters and label design, and applied INT8 quantization to reduce model size by 4x while maintaining 98% accuracy.", "Deployed the model within the X-Plane simulator using a plugin-based architecture with UDP-based IPC, enabling real-time inference with sub-500ms latency and integrating TTS feedback for closed-loop command validation."], "change": "modified", "section": "projects", "entry_id": "c4fa061d7bb2"}, {"after": ["Architected a high-concurrency transactional data pipeline using Node.js and MongoDB with sequential reconciliation to eliminate 100% of concurrent write conflicts.", "Integrated Google Gemini LLM API using structured prompt engineering and context summarization to automate real-time financial anomaly detection and accelerate risk identification."], "field": "highlights", "label": "USC Ledger – AI-Powered Financial Management Platform", "before": ["Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine to ensure 100% consistency across concurrent updates, producing reliable structured data for downstream analytics and modeling.", "Engineered feature processing logic using fixed-precision arithmetic and 800ms debounced writes to handle high-frequency financial events, reducing API load and ensuring stable inputs for real-time inference.", "Integrated LLM-based analytics using the Google Gemini API, designing prompt templates and context summarization to detect spending anomalies and generate structured financial insights from transaction data."], "change": "modified", "section": "projects", "entry_id": "575af85bce7f"}, {"after": null, "field": "items", "label": "Skills no longer shown", "before": ["A WS", "Evaluation", "Experimentation", "Hyperparameter Tuning", "NLP", "Statistical Analysis", "Tableau"], "change": "removed", "section": "skills", "entry_id": null}, {"after": ["Languages (7)", "Machine Learning & AI (7)", "Frameworks & Libraries (7)", "Data & Engineering (7)"], "field": "groups", "label": "Skill groups", "before": ["Languages (7)", "Machine Learning (7)", "F rameworks (6)", "Data & Systems (4)", "LLM & NLP (5)", "T ools (6)"], "change": "reordered", "section": "skills", "entry_id": null}]	{"locks": ["Employers & job titles", "Employment dates", "Schools, degrees & GPA", "Project names", "Contact details", "Awards, certifications & publications"], "violations": [{"kind": "fabricated_proper_noun", "field": "highlights", "action": "flagged", "detail": "Deloitte: mentions LLM-driven, which you never mention in your master resume. Confirm this is true before applying.", "entry_id": "b313a1ac95f3", "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Machine Learning & AI' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Frameworks & Libraries' was renamed by the model.", "entry_id": null, "severity": "warning"}, {"kind": "fabricated_proper_noun", "field": "skills", "action": "flagged", "detail": "Skill category 'Data & Engineering' was renamed by the model.", "entry_id": null, "severity": "warning"}], "bullet_confidence": [{"text": "Boosted core system throughput 10x by automating customer onboarding via rule-based Pega PRPC workflows across tax, credit, and legal chains across 35+ countries.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Engineered a sub-2s latency REST API orchestration layer linking Pega with Informatica MDM and SAP to ensure consistent propagation of master records.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Created LLM-driven categorization workflows with few-shot prompting, achieving 92% human annotation agreement via iterative feedback loops.", "label": "Deloitte", "reason": "Mentions LLM-driven, not found in your résumé.", "entry_id": "b313a1ac95f3", "confidence": "needs_review"}, {"text": "Built automated data preprocessing pipelines featuring quality checks, Z-score outlier filtering, and PII masking, reducing data preparation overhead by 30%.", "label": "Deloitte", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "b313a1ac95f3", "confidence": "likely"}, {"text": "Directed a 4-member engineering team to automate transient CFD simulations in PyFluent (k-omega SST, overset mesh), producing 1.2TB+ of aerodynamic data.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Extracted feature sets from pressure and force coefficients using multi-variate regression to model store-separation trajectories with ~99.8% data integrity.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Developed Python and MATLAB data pipelines featuring Z-score outlier filtering and time-series feature extraction to validate sensor models across 1.2TB+ of dataset runs.", "label": "Defence Research and Development Organisation (DRDO)", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "3553d3cab1a7", "confidence": "likely"}, {"text": "Engineered end-to-end ML data pipelines for 5M+ MRI/CT volumes using normalization, patch extraction, and class-balanced sampling to power production deep learning models.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Architected depthwise separable 3D CNNs for medical image segmentation, optimizing real-time inference latency under 0.8s for diagnostic deployment.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Designed SO(3)-equivariant CNN super-resolution models (e3nn) using rotation-equivariant convolutions, elevating volumetric image quality by 35% over baselines.", "label": "Prana.ai", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "961fac53e907", "confidence": "likely"}, {"text": "Constructed a synthetic data-generation pipeline outputting 30,000+ labeled voice commands using schema-driven templates and LLM paraphrasing (FLAN-T5).", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 model quantization to cut model footprint 4x.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Integrated real-time NLU inference into the X-Plane simulator via UDP IPC and plugin architecture, sustaining sub-500ms latency without interrupting execution loops.", "label": "Project Vimaan – AI V oice Command NLU System", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "c4fa061d7bb2", "confidence": "likely"}, {"text": "Architected a high-concurrency transactional data pipeline using Node.js and MongoDB with sequential reconciliation to eliminate 100% of concurrent write conflicts.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "575af85bce7f", "confidence": "likely"}, {"text": "Integrated Google Gemini LLM API using structured prompt engineering and context summarization to automate real-time financial anomaly detection and accelerate risk identification.", "label": "USC Ledger – AI-Powered Financial Management Platform", "reason": "Reworded; every number and named thing traces to your résumé.", "entry_id": "575af85bce7f", "confidence": "likely"}], "keywords_verified": [], "keywords_requested": ["Qualcomm"]}	t	Recruiter reached out on LinkedIn. Follow up next Tuesday.	61974	15960	0.012582	2026-08-06 18:20:03.069761+00	2026-08-09 03:33:50.233434+00	2026-08-13 02:24:00+00	2026-08-12 02:24:00+00	{"resume": {"cost_usd": 0.010043, "input_tokens": 44678, "output_tokens": 13936}, "outreach": {"cost_usd": 0.00014, "input_tokens": 764, "output_tokens": 160}, "cover_letter": {"cost_usd": 0.002399, "input_tokens": 16532, "output_tokens": 1864}}	["At Qualcomm, deploying high-performance machine learning models under strict compute and memory constraints requires deep expertise in both architecture design and runtime optimization. As a Founding Engineer at Prana.ai, I engineered end-to-end ML data pipelines processing over 5 million MRI and CT volumes and designed depthwise-separable 3D CNNs that achieved sub-0.8s inference latency for real-time diagnostic deployment. Applying similar performance-focused design in NLP through Project Vimaan, I fine-tuned DistilBERT for joint intent and entity extraction and implemented INT8 quantization, cutting the model footprint by 4x while sustaining sub-500ms execution. As a Machine Learning Engineer candidate, I am eager to bring this background in hardware-aware optimizations to Qualcomm's team.", "Developing scalable machine learning systems requires robust data pipelines and model refinement strategies. At Deloitte, I engineered automated data-preprocessing pipelines featuring Z-score outlier filtering and quality checks, reducing data preparation overhead by 30% for downstream analytics. I also created LLM-driven categorization workflows using few-shot and chain-of-thought prompting, establishing human-in-the-loop feedback mechanisms that achieved 92% agreement with expert annotations. Additionally, I architected an enterprise REST API orchestration layer connecting Pega, Informatica MDM, and SAP across 35+ countries, maintaining sub-2s latency and boosting system throughput tenfold to guarantee reliable data delivery.", "My engineering background spans advanced geometric deep learning alongside large-scale data processing. At Prana.ai, I designed SO(3)-equivariant super-resolution models using rotation-equivariant convolutions, boosting volumetric image resolution by 35% over baseline architectures. Furthermore, during my research internship at DRDO, I directed a four-member engineering team processing over 1.2TB of aerodynamic CFD simulation datasets, developing multi-variate regression models with Z-score outlier detection to achieve 99.8% data integrity. These experiences prepared me to manage both complex mathematical architectures and massive simulation datasets.", "Qualcomm's leadership in pushing efficient, hardware-accelerated AI execution to edge platforms aligns directly with my technical focus on quantized neural networks and low-latency pipeline engineering. Building on my MS in Computer Science at USC and my experience deploying quantized, real-time ML models into production, I look forward to discussing how my skills in model optimization and data pipeline design can advance Qualcomm's machine learning initiatives."]	f	\N	[{"at": "2026-08-09T03:17:33.329325+00:00", "kind": "cover_letter", "meta": {}, "label": "Cover letter updated"}, {"at": "2026-08-09T03:33:59.611841+00:00", "kind": "cover_letter", "meta": {}, "label": "Cover letter updated"}]	[{"at": "2026-08-06T18:20:03+00:00", "id": "6e7f049f-55d7-484d-b506-5ab48a0a968b", "text": "Recruiter reached out on LinkedIn. Follow up next Tuesday.", "updated_at": null}]
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.auth_tokens (id, user_id, token_hash, purpose, payload, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: career_profiles; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.career_profiles (id, user_id, headline, phone, location, linkedin_url, github_url, portfolio_url, website_url, work_authorization, visa_status, years_experience, preferred_roles, preferred_industries, preferred_locations, salary_min, salary_max, salary_currency, work_arrangement, open_to_relocation, created_at, updated_at, salary_period) FROM stdin;
434b0800-9e7e-4959-9023-68841493704a	f769aa0b-a466-4da4-94a7-e0019363a53a	Machine Learning Engineer specializing in LLM workflows and data pipelines	+1 2139945086	Los Angeles, CA	https://linkedin.com/in/hasnainraza03	https://github.com/hasnainrazaa03	https://hasnainrazaa.vercel.app/	\N	Require sponsorship now (student visa)	F-1 (Student)	2.5	["Machine Learning Engineer", "AI Engineer", "Software Engineer", "Backend Software Engineer"]	["Artificial Intelligence", "Machine Learning", "Enterprise Software", "Healthcare AI"]	["Los Angeles", "New York", "Seattle"]	120000	200000	USD	remote	t	2026-08-06 06:21:17.455744+00	2026-08-06 17:59:39.452253+00	\N
\.


--
-- Data for Name: evidence_items; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.evidence_items (id, user_id, kind, text, label, created_at, updated_at) FROM stdin;
effc02ea-06c6-4516-8f91-1e783f324605	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	Improved system throughput ~10x by automating manual customer onboarding with Pega PRPC workflows — rule-based routing across tax, credit, and legal approval chains for creation and modification requests.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
87301c7c-3eea-478b-a1be-27258b7edfec	f769aa0b-a466-4da4-94a7-e0019363a53a	SCOPE	Ran onboarding automation across 35+ countries, processing 7,500+ customer creations and 12,500+ modifications.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
40b1be18-e2fc-4564-a3df-fab3955fe1a7	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Built a REST API orchestration layer connecting Pega with Informatica MDM and downstream SAP systems, achieving sub-2s latency and consistent propagation of validated master records across distributed enterprise systems.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
4a1cce4e-4368-4ce7-a4dd-ad56ff2cc8ac	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	LLM-assisted request categorization using few-shot and chain-of-thought prompting reached 92% agreement with human annotations, refined through RLHF-style human-feedback loops.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
7e36207a-1fbe-439d-b312-a03fbc01d975	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	Data-preprocessing pipelines for LLM workflows — automated quality checks, Z-score outlier filtering, and PII masking — cut data-preparation effort 30%.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
8d4ac9fa-9b4d-408f-bc60-dfe82b1a4cd6	f769aa0b-a466-4da4-94a7-e0019363a53a	ACHIEVEMENT	Confirmed a 44% latency reduction with a Welch two-sample t-test (n=2,500+ samples, p<0.05), chosen deliberately for unequal variances and non-normal execution-time distributions.	Deloitte	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
11397342-1f62-45eb-8be7-29af0ab0b9ff	f769aa0b-a466-4da4-94a7-e0019363a53a	SCOPE	Led a 4-member team automating transient CFD simulations (PyFluent, k-omega SST, overset mesh) for weapons-bay store-separation studies, generating 1.2TB+ of aerodynamic data across multiple release conditions.	DRDO	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
a1cd448d-b210-4957-ac91-cdfdccf2293b	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Coded a C-based 6-DOF solver as an ANSYS Fluent user-defined function (UDF) to simulate gravity-driven store-separation trajectories.	DRDO	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
7d2f1cf0-7197-4dc9-ad68-6e58cc5c15b8	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Engineered features from pressure and force coefficients and applied multi-variate regression to model store-separation trajectories; Z-score outlier detection kept data integrity ~99.8%.	DRDO	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
fb0e9b18-71a4-46b8-a969-b8e32ffc7aff	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Built reusable Python and MATLAB pre/post-processing for terabyte-scale CFD output — time-series feature extraction, outlier filtering, and trajectory visualization validated against sensor data.	DRDO	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
972469a9-7f86-4adb-9e9d-32534ec325fc	f769aa0b-a466-4da4-94a7-e0019363a53a	SCOPE	Built end-to-end ML pipelines for 5M+ MRI/CT volumes — normalization, patch extraction, class-balanced sampling, and augmentation.	Prana.ai	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
e1caf2b0-90a9-4e81-8a98-838e2b260ca9	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	Designed and trained depthwise-separable 3D CNNs for medical image segmentation with under 0.8s inference latency for real-time diagnostic use.	Prana.ai	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
54dd536c-1cf8-4599-a6c1-d94b98684306	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	Developed SO(3)-equivariant CNN super-resolution models (e3nn), improving volumetric image quality ~35% over baseline.	Prana.ai	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
9fb5f518-4473-4c04-9d1b-b2afeb47525d	f769aa0b-a466-4da4-94a7-e0019363a53a	ACHIEVEMENT	As a founding engineer, helped secure a $50,000 pre-seed round by delivering production-ready ML prototypes.	Prana.ai	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
eaabb9da-4cea-42cd-a6d3-4f98dda1c79f	f769aa0b-a466-4da4-94a7-e0019363a53a	SCOPE	Built a data-generation pipeline producing 30,000+ labeled voice commands for joint intent-and-slot classification, using schema-driven templates and LLM-based paraphrasing (Pegasus, FLAN-T5).	Project Vimaan	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
994c3a25-c09d-4b6c-bada-78bf44eeaf27	f769aa0b-a466-4da4-94a7-e0019363a53a	IMPACT	Fine-tuned DistilBERT for joint intent and entity extraction (~98% accuracy) and applied INT8 quantization to cut model size ~4x while holding accuracy.	Project Vimaan	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
64833d35-7dcf-452b-bc92-fa07e595b1df	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Deployed into the X-Plane simulator via a plugin architecture with thread-safe UDP IPC and TTS feedback, holding real-time inference under 500ms — DistilBERT chosen for low latency, and NLU kept off the sim's execution loop so flight physics never degrade.	Project Vimaan	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
7f2c029f-12b6-46d7-b548-b2c467b60c2a	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine that resolves concurrent MongoDB write conflicts for strict, deterministic consistency — no partial or lost writes under rapid updates.	USC Ledger	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
e0ff6869-9d67-478f-8433-97a14ce68190	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Implemented precision-first financial logic with epsilon-aware, fixed-precision arithmetic to eliminate JavaScript floating-point errors in multi-currency tracking; 800ms debounced autosave and pagination prevent race conditions and server load.	USC Ledger	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
9d675d8a-9ad8-4a52-93dc-6f2fac7db677	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Integrated Google Gemini behind a structured prompt-engineering layer with a financial summarization step that condenses budget data before the model (preventing context overflow) to detect spending anomalies and generate structured insights.	USC Ledger	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
4ae98cde-b5e4-441c-8282-f9a0f84fafaa	f769aa0b-a466-4da4-94a7-e0019363a53a	CONTEXT	Explored Vision-Transformer-based 3D brain-tumor segmentation for clinical use cases (pre-surgery planning, radiofrequency ablation), including FEM-inspired physics-based refinement for structural plausibility of segmented regions.	BraTS 2021	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
a2b5eb55-184a-43b8-aaa7-64fd51de0610	f769aa0b-a466-4da4-94a7-e0019363a53a	SCOPE	Contributed CAD design and simulation to RVSAT-1, a 2U CubeSat launched aboard ISRO's PSLV C-60, then led a 100+ member interdisciplinary team spanning sponsorship, outreach, and execution across mechanical, electronics, propulsion, and software.	Team Antariksh	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
f372e164-91b9-415c-b9e9-7a710372907d	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Built a full-stack MERN recipe-management app — indexed and paginated MongoDB REST API, Firebase authentication with JWT verification, Cloudinary secure image uploads, debounced search, and a modular React frontend.	Manzil Recipe Vault	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
c78b365d-756c-41e5-983a-b0aab6fed160	f769aa0b-a466-4da4-94a7-e0019363a53a	ACHIEVEMENT	Pursuing an MS in Computer Science at USC with a perfect 4.00 GPA — coursework in algorithms, database systems, computer networks, programming system design, and machine learning.	USC	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
7dff28ce-66e5-4335-98a8-85ca8ad9037b	f769aa0b-a466-4da4-94a7-e0019363a53a	ACHIEVEMENT	BE in Aerospace Engineering from R.V. College of Engineering with a 3.86 GPA and a Silver Medal for academic performance.	Education	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
10d4be8e-4b5a-4f1d-b27d-2e8260dccf22	f769aa0b-a466-4da4-94a7-e0019363a53a	CONTEXT	Transitioned from aerospace-engineering research into software engineering and applied ML; experience spans enterprise software, healthcare AI, computational engineering, NLP, and financial AI systems.	Career	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
3b949d8e-fc20-4fe7-83c1-142b9a120660	f769aa0b-a466-4da4-94a7-e0019363a53a	SKILL	Strongest in Python (ML, data engineering, automation), with extensive JavaScript/TypeScript backend work and C/C++ from simulation and systems work; MongoDB and PostgreSQL with a focus on schema design, indexing, and transactional integrity.	Career	2026-08-06 06:21:29.015056+00	2026-08-06 06:21:29.015056+00
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.feature_flags (key, enabled, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.jobs (id, user_id, url, source, title, company, location, raw_text, requirements, created_at, updated_at) FROM stdin;
6f1390fd-5c2f-4098-8faa-94acf6adefbf	f769aa0b-a466-4da4-94a7-e0019363a53a	https://qualcomm.eightfold.ai/careers/job/446717859953	qualcomm.eightfold.ai	Machine Learning Engineer - College Graduate	Qualcomm	San Diego, CA,US	{"themeOptions": {"customTheme": {"varTheme": {"primary-color": "#3253dc", "primary-color-100": "#3253DC", "primary-color-90": "#4664E0", "primary-color-80": "#5B75E3", "primary-color-70": "#7087E6", "primary-color-60": "#8498EA", "primary-color-50": "#98A9EE", "primary-color-40": "#ADBAF1", "primary-color-30": "#C2CBF4", "primary-color-20": "#D6DDF8", "primary-color-10": "#EAEEFC", "pcsx-hero-image-height": "315px", "accent-color": "var(--primary-color)", "accent-color-10": "var(--primary-color-10)", "accent-color-20": "var(--primary-color-20)", "accent-color-30": "var(--primary-color-30)", "accent-color-40": "var(--primary-color-40)", "accent-color-50": "var(--primary-color-50)", "accent-color-60": "var(--primary-color-60)", "accent-color-70": "var(--primary-color-70)", "accent-color-80": "var(--primary-color-80)", "accent-color-90": "var(--primary-color-90)", "accent-color-100": "var(--primary-color-100)", "button-default-text-color": "var(--primary-color)", "button-default-background-color": "#ffffff", "button-default-border-color": "var(--primary-color)", "button-default-hover-text-color": "var(--primary-color)", "button-default-hover-background-color": "#ffffff", "button-default-hover-border-color": "var(--primary-color)", "button-default-active-text-color": "var(--primary-color)", "button-default-active-background-color": "#ffffff", "button-default-active-border-color": "var(--primary-color)", "button-primary-text-color": "#ffffff", "button-primary-background-color": "#2a2aea", "button-primary-hover-text-color": "#ffffff", "button-primary-hover-background-color": "#1c38a6", "button-primary-hover-border-color": "var(--primary-color)", "button-secondary-text-color": "#2a2aea", "button-secondary-border-color": "var(--primary-color)", "button-secondary-background-color": "#ffffff", "button-secondary-hover-background-color": "#ffffff", "button-secondary-hover-border-color": "var(--primary-color)", "tab-pill-active-label": "var(--text-inverse-color)", "perks-and-benefits-icon-color": "var(--primary-color)", "pcsx-jobcard-title-text-color": "#000", "pcsx-jobcard-flag-text-color": "#69717f", "pcsx-main-margin-top": "80px", "font-family": "Source Sans Pro", "pcsx-hero-image-background-size": "cover", "navbar-text-color": "#2c2e30", "navbar-text-hover-color": "#2a2aea", "button-secondary-hover-text-color": "#1c38a6", "navbar-text-hover-background": "#ffffff", "pcsx-theme-linear-gradient-end": "#020b3f", "pcsx-theme-linear-gradient-start": "#2a2aea", "info-bar-background-color": "#ffffff", "info-bar-button-active-background-color": "#ffffff", "pcsx-secondary-background-color": "#d3defa", "white-color": "#f5f6f7", "text-tertiary-color": "#000000", "text-secondary-color": "#000000", "border-radius-l": "4px", "border-radius-xs": "4px", "pcsx-match-bar-border": "f5f6f7", "border-radius-xl": "4px", "tab-active-label": "#2a2aea", "tab-indicator-color": "#2a2aea", "navbar-background": "#ffffff", "header-4-font-stack-full": "#2a2aea", "info-bar-positive-background-color": "#f0fefa", "info-bar-positive-button-active-background-color": "#f0fefa", "pcsx-two-state-button-border-color": "#1c38a6", "button-two-state-hover-text-color": "#ffffff", "button-two-state-hover-background-color": "#3253dc", "button-system-ui-text-color": "#000000", "button-system-ui-background-color": "var(--background-color)", "button-two-state-background-color": "#2a2aea", "button-two-state-text-color": "#ffffff", "button-two-state-checked-background-color": "#1c38a6", "button-two-state-checked-text-color": "#ffffff", "pcsx-insights-container-border": "1px solid", "pcsx-insights-container-color": "#dcdee1", "border-radius-s": "4px", "border-radius-round": "0%", "border-radius-m": "4px", "anchor-color": "2A2AEA", "pcsx-insights-header-gradient-start": "#2A2AEA", "button-system-ui-hover-text-color": "#000000", "text-inverse-color": "#000000", "pcsx-welcome-banner-text-color": "#ffffff", "button-system-ui-active-text-color": "#000000", "button-two-state-active-text-color": "#000000", "button-two-state-active-background-color": "#ffffff", "button-two-state-default-counter-background-color": "#1c38a6", "button-two-state-default-counter-text-color": "#ffffff", "button-two-state-hover-counter-background-color": "#3253dc", "button-two-state-checked-counter-background-color": "#1c38a6", "button-two-state-focus-counter-background-color": "#1c38a6", "button-two-state-active-counter-background-color": "#1c38a6", "pcsx-dashboard-tile-title-color": "#2a2aea"}, "customFonts": [{"fontFamily": "ALFABETREG", "src": "url('https://static.vscdn.net/images/careers/demo/qualcomm-sandbox/1758028778::Alfabet-Regular.otf')format('opentype')"}]}}, "domain": "qualcomm.com", "configPath": "PCS>", "updatePath": "PCS>"} {"navbarData": {"desktop": {"nav_left_items": [{"type": "BRANDING", "id": "branding", "product_homepage_url": "https://careers.qualcomm.com/careers", "company_name": "Qualcomm", "company_logo_url": "https://static.vscdn.net/images/careers/demo/qualcomm/1686210880::Qualcomm-Logo.png"}], "nav_right_items": [{"id": "company_info", "items": [{"external_link": true, "id": "about_us", "primary_text": "About Us", "target": "_blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company"}, {"external_link": true, "id": "company_careers", "primary_text": "Careers", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company/careers"}, {"external_link": true, "id": "company_responsibility", "primary_text": "ESG + Corporate Responsibility", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company/corporate-responsibility"}], "primary_text": "Our Company", "type": "DROPDOWN"}, {"id": "company_info", "items": [{"external_link": true, "id": "business_mobile", "primary_text": "Mobile", "target": "_blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#mobile"}, {"external_link": true, "id": "business_things", "primary_text": "Internet of Things", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#iot"}, {"external_link": true, "id": "business_auto", "primary_text": "Automotive", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#auto"}], "primary_text": "Our Business", "type": "DROPDOWN"}, {"type": "NAVLINK", "id": "search-for-jobs", "primary_text": "Search for Jobs", "url": "/careers"}, {"type": "NAVLINK", "id": "jtn_link", "primary_text": "Join Talent Network", "url": "/careers/join", "target": "_blank"}, {"type": "NAVLINK", "id": "faqs", "primary_text": "FAQs", "target": "_blank", "url": "https://www.qualcomm.com/company/careers/faqs", "external_link": true}, {"id": "profile_info", "items": [{"type": "NAVLINK", "primary_text": "Dashboard", "external_link": false, "id": "dashboard", "url": "/careers/dashboard"}, {"type": "NAVLINK", "id": "events", "primary_text": "Events", "url": "/events/open?domain=qualcomm.com", "target": "blank", "external_link": true}, {"type": "NAVLINK", "id": "benefits", "primary_text": "Benefits", "target": "_blank", "url": "https://www.qualcomm.com/company/careers/benefits", "external_link": true}], "primary_text": "Profile", "type": "DROPDOWN"}, {"type": "LANGUAGE_SWITCHER", "id": "language_switcher", "languages": [{"value": "en", "title": "English"}, {"value": "de", "title": "Deutsch"}, {"value": "zh-CN", "title": "\\u4e2d\\u6587 (\\u7b80\\u4f53)"}]}, {"type": "CANDIDATE_NOTIFICATION_CENTER", "id": "candidate_notification_center"}, {"type": "CANDIDATE_ACCOUNT", "id": "candidate_account", "items": [{"type": "NAVLINK", "id": "candidate_profile", "primary_text": "Profile", "url": "/careers/profile"}, {"type": "NAVLINK", "id": "candidate_settings", "primary_text": "Settings", "url": "/careers/settings"}], "user_image_url": null, "user_name": "Import qualcomm.com", "user_email": "import@qualcomm.com", "is_user_logged_in": "is_candidate_logged_in", "logged_in_candidate_info": {"is_logged_in": false}}]}, "mobile": {"nav_left_items": [{"type": "HAMBURGER_MENU", "id": "hamburger_menu", "icon": "mdiForwardBurger", "body_items": [{"id": "company_info", "items": [{"external_link": true, "id": "about_us", "primary_text": "About Us", "target": "_blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company"}, {"external_link": true, "id": "company_careers", "primary_text": "Careers", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company/careers"}, {"external_link": true, "id": "company_responsibility", "primary_text": "ESG + Corporate Responsibility", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/company/corporate-responsibility"}], "primary_text": "Our Company", "type": "DROPDOWN"}, {"id": "company_info", "items": [{"external_link": true, "id": "business_mobile", "primary_text": "Mobile", "target": "_blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#mobile"}, {"external_link": true, "id": "business_things", "primary_text": "Internet of Things", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#iot"}, {"external_link": true, "id": "business_auto", "primary_text": "Automotive", "target": "blank", "type": "NAVLINK", "url": "https://www.qualcomm.com/our-businesses?#auto"}], "primary_text": "Our Business", "type": "DROPDOWN"}, {"type": "NAVLINK", "id": "search-for-jobs", "primary_text": "Search for Jobs", "url": "/careers"}, {"type": "NAVLINK", "id": "benefits", "primary_text": "Benefits", "url": "https://www.qualcomm.com/company/careers/benefits", "external_link": true}, {"type": "NAVLINK", "id": "faqs", "primary_text": "FAQs", "url": "https://www.qualcomm.com/company/careers/faqs", "external_link": true}, {"type": "NAVLINK", "id": "jtn_link", "primary_text": "Join Talent Network", "url": "/careers/join", "target": "_blank"}, {"type": "NAVLINK", "id": "events", "primary_text": "Events", "url": "/events/open?domain=qualcomm.com", "target": "blank", "external_link": true}, {"type": "NAVLINK", "primary_text": "Dashboard", "external_link": false, "id": "dashboard", "url": "/careers/dashboard"}]}, {"type": "BRANDING", "id": "branding", "product_homepage_url": "https://careers.qualcomm.com/careers", "company_name": "Qualcomm", "company_logo_url": "https://static.vscdn.net/images/careers/demo/qualcomm/1686210880::Qualcomm-Logo.png"}], "nav_right_items": [{"type": "LANGUAGE_SWITCHER", "id": "language_switcher", "languages": [{"value": "en", "title": "English"}, {"value": "de", "title": "Deutsch"}, {"value": "zh-CN", "title": "\\u4e2d\\u6587 (\\u7b80\\u4f53)"}]}, {"type": "CANDIDATE_NOTIFICATION_CENTER", "id": "candidate_notification_center"}, {"type": "CANDIDATE_ACCOUNT", "id": "candidate_account", "items": [{"type": "NAVLINK", "id": "candidate_profile", "primary_text": "Profile", "url": "/careers/profile"}, {"type": "NAVLINK", "id": "candidate_settings", "primary_text": "Settings", "url": "/careers/settings"}], "user_image_url": null, "user_name": "Import qualcomm.com", "user_email": "import@qualcomm.com", "is_user_logged_in": "is_candidate_logged_in", "logged_in_candidate_info": {"is_logged_in": false}}]}, "customHtmlNavbarData": {"enable": false, "html": "<a href=\\"https://www.qualcomm.com/company/careers/faqs\\" target=\\"_blank\\" class=\\"faq-custom-header\\">FAQs</a>\\n<a href=\\"https://www.qualcomm.com/company/careers/benefits\\" target=\\"_blank\\" class=\\"faq-custom-header benefits\\">Benefits</a>\\n<a href=\\"https://app.eightfold.ai/careers?domain=qualcomm.com\\" target=\\"_blank\\" class=\\"faq-custom-header search-for-jobs\\">Search for Jobs</a>", "css": " .job-insights-section-title {\\n color: #000000 !important;\\n }\\n.job-card-title {width: 100%!important} @media screen and (min-width: 1500px) {\\n}\\n\\n.faq-custom-header {\\n float: right;\\n margin-right: 310px;\\n margin-top: 30px;\\n z-index: 9999999;\\n position: relative;\\n color: rgb(74, 90, 117) !important;\\n font-size: 20px !important;\\n}\\n@media screen and (max-width: 420px) and (min-width:281px){\\n .faq-custom-header {\\n margin-top: 0px;\\n top:30px;\\n right: 25px;\\n margin-right: 0px;\\n }\\n .faq-custom-header.benefits {\\n margin-right: -42px !important;\\n margin-top: -30px;\\n }\\n .faq-custom-header.search-for-jobs {\\n margin-right: -42px !important;\\n margin-top: 30px;\\n }\\n}\\n@media screen and (max-width: 820px) and (min-width:421px) {\\n .faq-custom-header {\\n margin-top: 0px;\\n top:58px;\\n }\\n .faq-custom-header.benefits {\\n margin-right: 15px !important;\\n }\\n .faq-custom-header.search-for-jobs {\\n margin-right: 15px !important;\\n }\\n}\\n@media screen and (max-width: 280px) {\\n.faq-custom-header {\\n margin-top: 0px;\\n top:90px;\\n margin-right: 245px;\\n}\\n}\\n.success-form .checkmark .fa-check {\\n color:#3253dc !important;\\n font-size: 100px !important;\\n}\\n\\n.success-form .browse-more .btn {\\n background-color: #fff;\\n border: 1px solid #3253dc !important;\\n color: #3253dc !important;\\n font-size: 14px;\\n font-weight: 600 !important;\\n line-height: 18px;\\n min-width: 145px;\\n text-align: center;\\n}\\n.upload-resume-modal .dropzone-container .btn {\\n background-color: #3253dc !important;\\n}\\n.upload-resume-modal .privacy-agreement .action-buttons .btn-sm {\\n border: 1px solid #3253dc !important;\\n}\\n.btn-primary, .btn-primary:hover, .btn-primary:focus, .btn-primary:active, .btn-primary.active, .open .dropdown-toggle.btn-primary, .btn-primary:active:focus, .btn-primary:active:hover, .btn-primary.active:hover, .btn-primary.active:focus {\\n color: #fff !important;\\n background-color: #3253dc !important;\\n}\\n.resume-name {\\n color: #3253dc;\\n}\\n.apply-form .position-apply-cancel-button {\\n border: 1px solid #3253dc !important;\\n color: #3253dc !important;\\n}\\n.apply-form .btn-primary {\\n background: #3253dc !important;\\n border-color: #3253dc !important;\\n}\\n.go-button {\\n border: 1px solid #3253dc;\\n color: #3253dc;\\n}\\n.btn-secondary, .btn-secondary:hover, .btn-secondary:focus, .btn-secondary:active, .btn-secondary.active, .open .dropdown-toggle.btn-secondary, .btn-secondary:active:focus, .btn-secondary:active:hover, .btn-secondary.active:hover, .btn-secondary.active:focus {\\n color: #3253dc !important;\\n border-color: #3253dc !important;\\n}\\n.add-to-job-cart-button {\\n border: 1px solid #3253dc !important;\\n color: #3253dc !important;\\n}\\n.position-card .position-title {\\n color: #3253dc;\\n}\\n.search-results-main-container .position-cards-container .card-selected {\\n border-left: 8px solid #3253dc;\\n}\\n.profile-dropdown .dropdown-title {\\n color: #3253dc !important;\\n}\\n.advanced-options-button {\\n color: #3253dc !important;\\n}\\n.fa-share {\\n color: #3253dc !important;\\n}\\n.position-facets .pillTitle {\\n color: #3253dc !important;\\n}\\n.perk .perk-icon {\\n color: #3253dc !important;\\n}\\n.join-tn-link {\\n position: relative;\\n top: 10px;\\n color: rgb(74, 90, 117) !important;\\n font-size: 20px !important;\\n}\\n.jobs-custom-header {\\n float: right;\\n margin-right: -190px;\\n margin-top: 30px;\\n z-index: 9999999;\\n position: relative;\\n color: rgb(74, 90, 117) !important;\\n font-size: 20px !important;\\n}\\n.ef-dropdown.language-dropdown .ef-dropdown-title {\\n color: rgb(74, 90, 117) !important;\\n font-size: 20px !important;\\n}\\n.upload-resume-modal .privacy-agreement .action-buttons .btn-sm.btn-secondary.pointer{\\n color: #3253dc !important;\\n}\\n.faq-custom-header.benefits {\\n margin-right: 20px;\\n}\\n.faq-custom-header.search-for-jobs{\\n margin-right: 20px;\\n}\\n.col-md-12.all-positions-header.col-sm-12.col-xs-12:after {\\n content: \\"Prior to uploading your resume, please ensure your location is included.\\";\\n}\\n.privacy-agreement > h2 {\\n\\tdisplay: none;\\n} \\n\\n\\n#careers-apply-form .question-title {\\n\\tmargin-left: 7px !important;\\n}", "stylesheets": [], "scripts": [], "inject_in_html_template": true}}, "isUiRefreshGateEnabled": 1, "isEmailWizardV2Enabled": 0, "isNavbarImproveSearchResultsEnabled": 1, "isTaBulkActionsUseIngestFrameworkGateEnabled": true, "isTaPipelineUxRefreshGateEnabled": 1, "product": "PCS", "instanceBannerData": {"display_banner": false, "display_text": ""}, "isEnabledForImpersonationWarning": false, "isEnabledForSuggestedLogins": 0, "forceRenderNewNavbar": false, "aiiStandaloneEnabled": false} {"domain": "qualcomm.com", "configs": {"pcsxConfig": {"enabled": true, "searchConfig": {"basePositionFq": "is_posted:true AND is_externally_posted:true AND position.is_confidential:false", "smartFilters": ["distance"], "allFilters": ["job_family", "skills", "seniority"], "locationRadiusDistanceDefault": 80, "locationSearch": {"autoFillLocationConfig": {"enabled": false, "locationSpecificity": "country"}}, "includeRemoteDefault": false, "includeRelocationAllowedDefault": false, "enableMocTranslations": true, "currentLocation": "Exact", "mapConfig": {"enabled": true, "facetLimit": 100, "isMapOpenByDefault": false, "markers": {"defaultMarker": {"color": "#074999"}, "selectedMarker": {"color": "#074999"}}, "disableInMobile": false}, "savedSearchConfig": {"limit": 5}, "locationSuggestDict": "position_profile_locations", "excludePrivatePositions": true, "sortOptionsConfig": {"hideCompanyPrioritySort": true, "hideProfileMatchSort": false}, "searchFields": {"useAtsLocationSource": false, "departmentField": "job_function"}, "strongMatchThreshold": 4.0, "fallbackSiteFq": "has_job_description: 1", "membershipFq": "", "searchBoxConfig": {"presetOptions": []}, "locationEnableGeocodeNormalization": true}, "positionDetailsConfig": {"tabsDisplayConfig": [{"id": "jd", "sections": ["position_fields", "jd"], "label": "Job description", "showInsightsWidget": true}, {"id": "company", "sections": ["perks", "videos", "blogs", "position_custom_content"], "label": "Company and benefits", "showInsightsWidget": false}], "sectionsConfig": {"perks": {"items": [{"title": "Health", "description": "Qualcomm offers a world-class health benefit option providing world-class coverage to employees and their eligible dependents.", "image": "https://static.vscdn.net/images/careers/demo/qualcomm/1772302566::heart-pulse.png", "imageAlt": "Heart with a pulse line", "icon": "fas fa-user-md", "isFavicon": true}, {"title": "Wealth", "description": "Our programs are designed to help employees build and prepare for a financially secure future.", "image": "https://static.vscdn.net/images/careers/demo/qualcomm/1772302578::circle-dollar-sign.png", "imageAlt": "Dollar sign within a circle", "icon": "fa-coins", "isFavicon": true}, {"title": "Self", "description": "Our self and family resources help you build emotional/mental strength and resilience, as well as define your purpose \\u2014 in life and at work.", "image": "https://static.vscdn.net/images/careers/demo/qualcomm/1772302588::hand-heart.png", "imageAlt": "Hand holding a heart", "icon": "fas fa-hand-holding-heart", "isFavicon": true}, {"title": "Wellbeing", "description": "Qualcomm\\u2019s wellbeing programs and resources offer support to help employees Live+Well and Work+Well, so they can unlock their full potential at home, at work, and everywhere between.", "image": "https://static.vscdn.net/images/careers/demo/qualcomm/1772302598::scale.png", "imageAlt": "A scale", "icon": "fas fa-balance-scale", "isFavicon": true}]}, "blogs": {"items": ["https://www.qualcomm.com/news/onq/2025/05/qualcomm-at-40-heres-how-we-drove-five-of-the-biggest-tech-revolutions", "https://www.qualcomm.com/news/onq/2025/03/getting-ready-for-next-era-of-wireless-connectivity-global-6g-tech-standardization", "https://www.qualcomm.com/news/onq/2024/12/innovating-the-next-generation-of-wireless-systems-meet-prashanth-hande", "https://www.qualcomm.com/news/onq/2024/02/rooted-in-tomorrow-qualcomm-and-its-inventors-are-focused-on-the-future"]}, "videos": {"items": ["https://www.youtube-nocookie.com/embed/qwsr069ybKA", "https://www.youtube-nocookie.com/embed/AM4pwYUL2AY", "https://www.youtube-nocookie.com/embed/JJbJ72UeMCg", "https://www.youtube-nocookie.com/embed/l2LT5mi6kG0", "https://www.youtube-nocookie.com/embed/ccqTTORpYFQ"]}, "positionFields": {"fields": [{"fieldName": "display_job_id", "label": "Job ID", "type": "text", "format": null}], "fieldsToDisplay": null}, "positionInsightsConfig": {"enabled": true, "insightsFields": ["skills", "company", "experience_years", "titles"], "insightsFq": "{hired_similar_jobs}", "sourceInsightsFromGroupId": null}, "pymwwConfig": {"isEnabled": false, "fq": ""}, "positionCustomContent": {"items": [{"body": "<p>Whether you’re launching a new career or ready to explore what’s next in the evolution of your talent and expertise, you’re about to embark on a career growth journey like no other.</p> <p><strong>Bring out your best, with the best<br /></strong>Our employees make Qualcomm’s success possible. We hire the brightest minds and foster a supportive, inclusive culture where your ideas have the power to contribute to world-changing innovations and breakthrough technologies. To make that possible, we leverage the breadth and depth of our diverse expertise from around the world to answer the unasked, conquer the complex, and solve some of the biggest challenges only we can – together.</p> <p><strong>Innovate with technology experts<br /></strong>At Qualcomm, we are passionate about the limitless potential of your career. Only here can you work alongside some of the most respected, leading engineering and technology experts in the industry – helping you learn and grow professionally in ways you haven’t yet imagined.</p> <p><strong>Live well, work well<br /></strong>Additionally, you’ll have access to programs such as our continuous learning and development programs, tuition reimbursement, and mentorships to tap into your limitless potential – plus, opportunities to enhance your quality of life through our comprehensive, best-in-class benefits offerings.</p> <p>The work we do at Qualcomm impacts lives around the globe – and you can be part of it. Apply today and unlock your full potential.</p>", "title": "Unlock Your Limitless Potential with Qualcomm"}]}, "matchDetailsConfig": {"enabled": true, "showTopApplicantInsights": false, "allowMocInsights": false, "showRelevantExperience": true, "showPreviouslyWorkedAt": true, "showWorkCategoryOverlap": true, "showSchool": true, "showSkills": true}, "similarPositionConfig": {"showSimilarJobsOrderedByViewedPositionLocation": false, "similarJobLookupRadiusKm": 20}}}, "branding": {"companyName": "Qualcomm", "companyLogo": null, "privacyHtml": "By clicking the \\"Submit My Resume\\" button below, you acknowledge that you have read Qualcomm's <a style='color: var(--anchor-color);' href='https://www.qualcomm.com/site/job-application-privacy-notice' target='_blank'>Job Application Privacy Notice</a> and understand how Qualcomm may process your job application data, including using AI-enabled functionalities.", "privacy": {"defaultLoggedOutContactConsent": null, "defaultLoggedOutCampaignConsent": null}, "customPageSections": {"footer": "", "customNavbarConfig": {"enable": false, "html": "<a href=\\"https://www.qualcomm.com/company/careers/faqs\\" target=\\"_blank\\" class=\\"faq-custom-header\\">FAQs</a>\\n<a href=\\"https://www.qualcomm.com/company/careers/benefits\\" target=\\"_blank\\" class=\\"faq-custom-header benefits\\">Benefits</a>\\n<a href=\\"https://app.eightfold.ai/careers?domain=qualcomm.com\\" target=\\"_blank\\" class=\\"faq-custom-header search-for-jobs\\">Search for Jobs</a>", "css": " .job-insights-section-title {\\n color: #000000 !important;\\n }\\n.job-card-title {width: 100%!important} @media screen and (min-width: 1500px) {\\n}\\n\\n.faq-custom-header {\\n float: right;\\n margin-right: 310px;\\n margin-top: 30px;\\n z-index: 9999999;\\n position: relative;\\n color: rgb(74, 90, 117) !important;\\n font-size: 20px !important;\\n}\\n@media screen and (max-width: 420px) and (min-width:281px){\\n .faq-custom-header {\\n margin-top: 0px;\\n top:30px;\\n right: 25px;\\n margin-right: 0px;\\n }\\n .faq-custom-header.benefits {\\n margin-right: -42px !important;\\n margin-top: -30px;\\n }\\n .faq-custom-header.search-for-jobs {\\n margin-right: -42px !important;\\n margin-top: 30px;\\n }\\n}\\n@m	{"title": "Machine Learning Engineer - College Graduate", "company": "Qualcomm", "location": "San Diego, CA,US", "seniority": "unknown", "salary_text": null, "ats_keywords": ["Qualcomm"], "qualifications": [], "employment_type": "unknown", "required_skills": [], "preferred_skills": [], "responsibilities": [], "min_years_experience": null, "education_requirement": null}	2026-08-06 18:20:03.069761+00	2026-08-06 18:20:15.503471+00
576bdc10-79c5-43b6-91bd-ad548ccc2eff	f769aa0b-a466-4da4-94a7-e0019363a53a	https://joinbytedance.com/search/7515577680822831367	joinbytedance.com	Machine Learning Engineer Graduate (TikTok E-Commerce - Conversational AI)-2026 Start (PhD)	ByteDance	\N	Life at ByteDance\nOur Culture\nOur Philosophy\nTeams\nAdvertising & Sales\nCorporate Functions\nDesign\nE-Commerce\nGlobal Operations\nMarketing & Communications\nProduct\nTechnology\nHow We Hire\nApplying to ByteDance\nInterview Tips\nFrequently Asked Questions\nLocations\nEarly Careers\nEarly Careers at ByteDance\nAmericas\nAsia Pacific\nEurope, the UK and the Middle East\nGlobal Frontier Tech Recruitment Program\nPhD Opportunities\nFAQs\nBlog\nJobs\nApply\n日本語\nJoin us as we work together to\ninspire creativity and enrich life\naround the globe.\nLife at ByteDance\nEarly Careers\nAmericas\nAsia Pacific\nEurope and Middle East\nEarly Careers FAQ\nTeams\nTechnology\nProduct\nDesign\nMarketing & Communications\nCorporate Functions\nGlobal Operations\nAdvertising & Sales\nHow We Hire\nFAQ\nInterview Tips\nLocations\nBlog\nLegal\nOther Open Roles\nCareers @ TikTok\nCareers in China\n© 2012-2025 ByteDance	{"title": "Machine Learning Engineer Graduate (TikTok E-Commerce - Conversational AI)-2026 Start (PhD)", "company": "ByteDance", "location": null, "seniority": "unknown", "salary_text": null, "ats_keywords": [], "qualifications": [], "employment_type": "unknown", "required_skills": [], "preferred_skills": [], "responsibilities": [], "min_years_experience": null, "education_requirement": null}	2026-08-07 17:17:57.251666+00	2026-08-07 17:18:18.552336+00
169656c6-b76d-4eef-b32d-c40772821432	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	pasted	Machine Learning Engineer – New Grad	Acme AI	San Francisco, CA (Hybrid)	Machine Learning Engineer – New Grad\n\nCompany: Acme AI\nLocation: San Francisco, CA (Hybrid)\n\nAbout the role\n\nWe're looking for a Machine Learning Engineer to build production ML systems powering personalization, recommendations, and intelligent automation.\n\nResponsibilities\n\n• Build and deploy machine learning models for recommendation and ranking.\n• Design scalable data pipelines for model training and evaluation.\n• Work with Python, PyTorch, TensorFlow, and SQL.\n• Build REST APIs to serve machine learning models.\n• Collaborate with backend engineers and data scientists.\n• Monitor model performance and retrain models as data evolves.\n• Improve latency and scalability of inference systems.\n\nQualifications\n\n• BS or MS in Computer Science or related field.\n• Strong Python programming skills.\n• Experience with machine learning and deep learning.\n• Familiarity with PyTorch or TensorFlow.\n• Experience building data pipelines.\n• Understanding of REST APIs.\n• Experience with Docker and cloud platforms is a plus.\n• Strong communication and teamwork skills.\n\nPreferred\n\n• NLP or LLM experience.\n• Hugging Face Transformers.\n• Distributed systems.\n• Experiment tracking.\n• AWS.	{"title": "Machine Learning Engineer – New Grad", "company": "Acme AI", "location": "San Francisco, CA (Hybrid)", "seniority": "entry", "salary_text": null, "ats_keywords": ["Python", "PyTorch", "TensorFlow", "Machine Learning", "Deep Learning", "REST APIs", "SQL", "Data Pipelines", "Docker", "AWS", "NLP", "LLM", "Hugging Face Transformers", "Distributed systems", "Experiment tracking"], "qualifications": ["BS or MS in Computer Science or related field.", "Strong Python programming skills.", "Experience with machine learning and deep learning.", "Familiarity with PyTorch or TensorFlow.", "Experience building data pipelines.", "Understanding of REST APIs.", "Experience with Docker and cloud platforms is a plus.", "Strong communication and teamwork skills."], "employment_type": "full_time", "required_skills": [{"name": "Python", "category": "Programming Languages", "importance": 5}, {"name": "Machine Learning", "category": "AI/ML", "importance": 5}, {"name": "Deep Learning", "category": "AI/ML", "importance": 5}, {"name": "PyTorch", "category": "Frameworks", "importance": 4}, {"name": "TensorFlow", "category": "Frameworks", "importance": 4}, {"name": "Data Pipelines", "category": "Data Engineering", "importance": 4}, {"name": "REST APIs", "category": "Software Engineering", "importance": 4}, {"name": "SQL", "category": "Databases", "importance": 3}], "preferred_skills": [{"name": "Docker", "category": "DevOps", "importance": 2}, {"name": "Cloud Platforms", "category": "Cloud", "importance": 2}, {"name": "NLP", "category": "AI/ML", "importance": 2}, {"name": "LLM", "category": "AI/ML", "importance": 2}, {"name": "Hugging Face Transformers", "category": "Frameworks", "importance": 2}, {"name": "Distributed Systems", "category": "Software Engineering", "importance": 2}, {"name": "Experiment Tracking", "category": "AI/ML", "importance": 2}, {"name": "AWS", "category": "Cloud", "importance": 2}], "responsibilities": ["Build and deploy machine learning models for recommendation and ranking.", "Design scalable data pipelines for model training and evaluation.", "Work with Python, PyTorch, TensorFlow, and SQL.", "Build REST APIs to serve machine learning models.", "Collaborate with backend engineers and data scientists.", "Monitor model performance and retrain models as data evolves.", "Improve latency and scalability of inference systems."], "min_years_experience": null, "education_requirement": "BS or MS in Computer Science or related field"}	2026-08-07 17:22:09.015281+00	2026-08-07 17:22:29.860804+00
db327ef6-5908-4e2e-8661-7ceef7fef7e2	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	pasted	Backend Software Engineer – Distributed Systems	Nimbus Cloud	San Francisco, CA (Hybrid)	Backend Software Engineer – Distributed Systems\n\nCompany: Nimbus Cloud\n\nLocation: San Francisco, CA (Hybrid)\n\nAbout the Role\n\nWe're building large-scale distributed backend services powering millions of requests every day. We're looking for an early-career Backend Software Engineer who enjoys building reliable APIs, scalable data pipelines, and distributed infrastructure.\n\nResponsibilities\n\n• Design and build RESTful APIs using Python or Node.js.\n• Build scalable backend services and distributed systems.\n• Design data models and work with PostgreSQL or MongoDB.\n• Optimize API latency and throughput.\n• Build ETL and data processing pipelines.\n• Improve reliability, observability, and monitoring.\n• Collaborate with frontend engineers and product teams.\n• Deploy services using Docker and cloud infrastructure.\n• Write automated tests and participate in code reviews.\n\nQualifications\n\n• BS/MS in Computer Science or related field.\n• Strong Python or Node.js programming.\n• Experience designing REST APIs.\n• Experience working with SQL or NoSQL databases.\n• Understanding of distributed systems fundamentals.\n• Familiarity with Docker.\n• Experience with AWS, GCP, or Azure is a plus.\n\nPreferred\n\n• Microservices.\n• Event-driven architectures.\n• Kafka or RabbitMQ.\n• Kubernetes.\n• CI/CD pipelines.\n• Performance optimization.	{"title": "Backend Software Engineer – Distributed Systems", "company": "Nimbus Cloud", "location": "San Francisco, CA (Hybrid)", "seniority": "entry", "salary_text": null, "ats_keywords": ["Python", "Node.js", "RESTful APIs", "REST APIs", "distributed systems", "PostgreSQL", "MongoDB", "SQL", "NoSQL", "Docker", "AWS", "GCP", "Azure", "Microservices", "Kafka", "RabbitMQ", "Kubernetes", "CI/CD"], "qualifications": ["BS/MS in Computer Science or related field.", "Strong Python or Node.js programming.", "Experience designing REST APIs.", "Experience working with SQL or NoSQL databases.", "Understanding of distributed systems fundamentals.", "Familiarity with Docker.", "Experience with AWS, GCP, or Azure is a plus."], "employment_type": "full_time", "required_skills": [{"name": "Python", "category": "Languages", "importance": 5}, {"name": "Node.js", "category": "Languages", "importance": 5}, {"name": "REST APIs", "category": "Architecture", "importance": 5}, {"name": "SQL", "category": "Databases", "importance": 5}, {"name": "NoSQL", "category": "Databases", "importance": 5}, {"name": "Distributed systems", "category": "Concepts", "importance": 5}, {"name": "Docker", "category": "Tools", "importance": 5}], "preferred_skills": [{"name": "AWS", "category": "Cloud", "importance": 3}, {"name": "GCP", "category": "Cloud", "importance": 3}, {"name": "Azure", "category": "Cloud", "importance": 3}, {"name": "Microservices", "category": "Architecture", "importance": 3}, {"name": "Event-driven architectures", "category": "Architecture", "importance": 3}, {"name": "Kafka", "category": "Tools", "importance": 3}, {"name": "RabbitMQ", "category": "Tools", "importance": 3}, {"name": "Kubernetes", "category": "Tools", "importance": 3}, {"name": "CI/CD pipelines", "category": "DevOps", "importance": 3}, {"name": "Performance optimization", "category": "Concepts", "importance": 3}], "responsibilities": ["Design and build RESTful APIs using Python or Node.js.", "Build scalable backend services and distributed systems.", "Design data models and work with PostgreSQL or MongoDB.", "Optimize API latency and throughput.", "Build ETL and data processing pipelines.", "Improve reliability, observability, and monitoring.", "Collaborate with frontend engineers and product teams.", "Deploy services using Docker and cloud infrastructure.", "Write automated tests and participate in code reviews."], "min_years_experience": null, "education_requirement": "BS/MS in Computer Science or related field."}	2026-08-08 03:13:45.056879+00	2026-08-08 03:44:07.734905+00
\.


--
-- Data for Name: llm_usage; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.llm_usage (id, user_id, application_id, purpose, model, input_tokens, output_tokens, cost_usd, latency_ms, succeeded, created_at, updated_at) FROM stdin;
05a16f10-a761-4b65-be02-6fe97a8d1026	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	653	366	0.000212	3759	t	2026-08-06 18:19:27.791182+00	2026-08-06 18:19:27.791182+00
b9e2c430-a440-439b-b4ea-db017cc9e1a1	f769aa0b-a466-4da4-94a7-e0019363a53a	96b6bc24-f3c5-498b-92dd-3dc732104005	extract_requirements	gemini-flash-latest	8226	120	0.000871	1832	t	2026-08-06 18:20:15.503471+00	2026-08-06 18:20:15.503471+00
e5e39e1f-70b0-4bc0-8297-baac0f7ecd05	f769aa0b-a466-4da4-94a7-e0019363a53a	96b6bc24-f3c5-498b-92dd-3dc732104005	plan_coverage	gemini-flash-latest	3209	40	0.000337	1097	t	2026-08-06 18:20:15.503471+00	2026-08-06 18:20:15.503471+00
87be4ad0-afd5-4fca-8cec-bd81c8e8b72f	f769aa0b-a466-4da4-94a7-e0019363a53a	96b6bc24-f3c5-498b-92dd-3dc732104005	optimize_resume	gemini-flash-latest	6600	1419	0.001228	7067	t	2026-08-06 18:20:15.503471+00	2026-08-06 18:20:15.503471+00
f8626567-6201-40a8-a139-417a0b9fbb11	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2143	1329	0.000746	6441	t	2026-08-06 20:59:12.544581+00	2026-08-06 20:59:12.544581+00
f81d5805-4aa0-49bf-accc-d619ab5a2fc6	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	cover_letter	gemini-flash-latest	3361	400	0.000496	3995	t	2026-08-06 20:59:40.699167+00	2026-08-06 20:59:40.699167+00
ebdd7f56-3c8f-4de0-9f57-527f682c5172	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	outreach_recruiter_email	gemini-flash-latest	762	192	0.000153	1863	t	2026-08-06 20:59:46.19784+00	2026-08-06 20:59:46.19784+00
402aa2a7-4ad6-4789-a12f-22627bad3ab9	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	outreach_follow_up	gemini-flash-latest	764	160	0.00014	2444	t	2026-08-06 21:09:33.269438+00	2026-08-06 21:09:33.269438+00
e5bc6ee6-ed75-46cc-a05e-592ddeac3e59	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	copilot	gemini-flash-latest	1886	125	0.000239	2131	t	2026-08-06 21:09:46.571584+00	2026-08-06 21:09:46.571584+00
9c938d99-6ed5-4583-a86e-a05f10bf59a7	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2152	1203	0.000696	6189	t	2026-08-07 00:10:29.723944+00	2026-08-07 00:10:29.723944+00
1dbd22fb-309d-4ce9-bf2a-65ddf0a12c86	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2121	1280	0.000724	5790	t	2026-08-07 00:11:01.458304+00	2026-08-07 00:11:01.458304+00
1125f069-1433-4a2a-bf64-262946776a9d	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2185	1171	0.000687	5510	t	2026-08-07 01:33:35.849751+00	2026-08-07 01:33:35.849751+00
3cb31cfb-1aed-4e77-abbc-ef3f177094bf	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2193	928	0.000591	4680	t	2026-08-07 01:34:08.216131+00	2026-08-07 01:34:08.216131+00
1af9134b-94dc-4fa8-a020-2a438c879b49	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2207	1223	0.00071	5067	t	2026-08-07 01:34:19.108854+00	2026-08-07 01:34:19.108854+00
a53c1b4f-8e2e-4a7c-8652-cdeec796736e	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2205	1302	0.000741	5779	t	2026-08-07 01:34:30.008116+00	2026-08-07 01:34:30.008116+00
719388c9-c53e-439f-a3b0-10f510a46b3d	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2209	933	0.000594	4154	t	2026-08-07 01:50:03.007037+00	2026-08-07 01:50:03.007037+00
0b43e534-c302-43a7-adc7-38a7794dd3f7	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	copilot	gemini-flash-latest	1869	332	0.00032	6371	t	2026-08-07 02:55:28.353014+00	2026-08-07 02:55:28.353014+00
9871503d-848d-4072-928c-e831947111d4	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	698	365	0.000216	3045	t	2026-08-07 02:56:18.166793+00	2026-08-07 02:56:18.166793+00
a23e0c17-8744-443f-bd11-3f8191e99cf9	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	880	321	0.000216	3237	t	2026-08-07 07:53:13.620627+00	2026-08-07 07:53:13.620627+00
80021059-186f-4b3a-a877-3c450de35a73	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	cover_letter	gemini-flash-latest	3881	435	0.000562	7162	t	2026-08-07 17:06:40.839787+00	2026-08-07 17:06:40.839787+00
2b6b4001-4d8b-4214-becd-43539a6859cb	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	cover_letter	gemini-flash-latest	4204	416	0.000587	7104	t	2026-08-07 17:07:07.803203+00	2026-08-07 17:07:07.803203+00
76791731-8e3a-4719-9a53-02b25f6d79c4	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	661	347	0.000205	3020	t	2026-08-07 17:12:44.166637+00	2026-08-07 17:12:44.166637+00
b8279de3-b5b3-4132-a459-e330cfeff9fd	f769aa0b-a466-4da4-94a7-e0019363a53a	f77713d6-8e35-45ce-b889-ea350a6f05c4	extract_requirements	gemini-flash-latest	457	68	7.3e-05	1567	t	2026-08-07 17:18:18.552336+00	2026-08-07 17:18:18.552336+00
11ec39e5-d75f-450e-be7a-ec8d6c79ce47	f769aa0b-a466-4da4-94a7-e0019363a53a	f77713d6-8e35-45ce-b889-ea350a6f05c4	plan_coverage	gemini-flash-latest	3210	9	0.000325	1038	t	2026-08-07 17:18:18.552336+00	2026-08-07 17:18:18.552336+00
6ce0c194-41b1-42fc-a237-5ffc25370243	f769aa0b-a466-4da4-94a7-e0019363a53a	f77713d6-8e35-45ce-b889-ea350a6f05c4	optimize_resume	gemini-flash-latest	4662	1263	0.000971	10841	t	2026-08-07 17:18:18.552336+00	2026-08-07 17:18:18.552336+00
c9b8b1e9-ad58-4cb1-848c-384978e9e636	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	extract_requirements	gemini-flash-latest	494	508	0.000253	2735	t	2026-08-08 03:14:06.55331+00	2026-08-08 03:14:06.55331+00
324e8650-31d7-45dd-9cbb-90b698cc48e6	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	plan_coverage	gemini-flash-latest	3282	755	0.00063	3416	t	2026-08-08 03:14:06.55331+00	2026-08-08 03:14:06.55331+00
884c308e-aeed-4c76-9c41-ba3c4a05dcc5	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	optimize_resume	gemini-flash-latest	5936	1404	0.001155	6759	t	2026-08-08 03:14:06.55331+00	2026-08-08 03:14:06.55331+00
f5846289-4b4b-4cb5-a508-ba187df4ad6a	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	cover_letter	gemini-flash-latest	2403	475	0.00043	5809	t	2026-08-08 03:14:06.55331+00	2026-08-08 03:14:06.55331+00
3e8b4192-d4b3-4461-829c-bc66edab87f8	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	extract_requirements	gemini-flash-latest	494	510	0.000253	2631	t	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
62e8c39e-bb62-401d-b935-c017af8149e1	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	plan_coverage	gemini-flash-latest	3287	804	0.00065	3373	t	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
1c8a75f4-770e-4512-a75b-b4418952f596	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	optimize_resume	gemini-flash-latest	5973	1429	0.001169	6727	t	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
b1d7318f-d742-48a6-a6b9-05d7ec278f28	f769aa0b-a466-4da4-94a7-e0019363a53a	193ff2ff-7bf6-4d15-b4c8-560463842f49	cover_letter	gemini-flash-latest	2392	383	0.000392	4310	t	2026-08-08 03:44:07.734905+00	2026-08-08 03:44:07.734905+00
660766f8-ea08-4b84-beeb-9ef96c9fa2ba	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2552	1199	0.000735	5947	t	2026-08-08 07:47:32.167478+00	2026-08-08 07:47:32.167478+00
91d8b664-8b89-4c3d-9867-086a15cd14c8	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	750	324	0.000205	2682	t	2026-08-09 01:22:02.271652+00	2026-08-09 01:22:02.271652+00
1165d519-5f36-4c70-93d6-67613b527233	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	revise_resume	gemini-flash-latest	2553	1197	0.000734	5464	t	2026-08-09 01:43:58.911365+00	2026-08-09 01:43:58.911365+00
8d2b1174-6169-4ef7-9dc8-df3fd24ff03a	f769aa0b-a466-4da4-94a7-e0019363a53a	96b6bc24-f3c5-498b-92dd-3dc732104005	cover_letter	gemini-flash-latest	4173	492	0.000614	6420	t	2026-08-09 03:17:25.492373+00	2026-08-09 03:17:25.492373+00
690c30a1-d55b-4294-99c3-f398a9e0c82b	f769aa0b-a466-4da4-94a7-e0019363a53a	96b6bc24-f3c5-498b-92dd-3dc732104005	cover_letter	gemini-flash-latest	4274	521	0.000636	7909	t	2026-08-09 03:33:50.233434+00	2026-08-09 03:33:50.233434+00
c76d9f29-7956-4039-9d4d-afbde2d75437	f769aa0b-a466-4da4-94a7-e0019363a53a	f77713d6-8e35-45ce-b889-ea350a6f05c4	cover_letter	gemini-flash-latest	2808	468	0.000468	3578	t	2026-08-09 03:57:49.386193+00	2026-08-09 03:57:49.386193+00
72aa51c0-9034-4934-8f85-0058f2d473d4	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	cover_letter	gemini-flash-latest	3029	466	0.000489	10712	t	2026-08-09 04:03:04.749346+00	2026-08-09 04:03:04.749346+00
6047c140-a1b1-4383-8865-93435a33611f	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	interview_questions	gemini-flash-latest	731	907	0.000436	6357	t	2026-08-09 20:10:18.991662+00	2026-08-09 20:10:18.991662+00
183caf95-27a8-4183-ac07-8b15808e55c1	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	interview_answer	gemini-flash-latest	2236	214	0.000309	6540	t	2026-08-09 20:16:18.283571+00	2026-08-09 20:16:18.283571+00
cdec0e2c-1b7b-4ead-ae5c-e577699bdc0d	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	interview_answer	gemini-flash-latest	2365	215	0.000322	2792	t	2026-08-09 20:18:31.333053+00	2026-08-09 20:18:31.333053+00
a4db4642-5cba-40e1-912e-85579c762ceb	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	job_rerank	gemini-flash-latest	618	371	0.00021	3619	t	2026-08-09 22:18:23.908556+00	2026-08-09 22:18:23.908556+00
bac6e9d2-c520-4b97-969e-27420f038488	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	interview_questions	gemini-flash-latest	731	943	0.00045	6077	t	2026-08-09 23:38:47.673493+00	2026-08-09 23:38:47.673493+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.notifications (id, user_id, kind, title, body, link, dedupe_key, read_at, created_at, updated_at) FROM stdin;
7e2b2a2c-e480-48ef-b612-2db3fafef5ec	f769aa0b-a466-4da4-94a7-e0019363a53a	weekly_summary	Your weekly job-search summary	This week: 0 in progress, 0 interviewing, 0 offer(s). Response rate 0%. Keep the momentum going.	/analytics	weekly:2026-W32	\N	2026-08-07 06:09:30.78707+00	2026-08-07 06:09:30.78707+00
ae5596f1-4533-4fdd-9027-16fd4b40e6c1	f769aa0b-a466-4da4-94a7-e0019363a53a	weekly_summary	Your weekly job-search summary	This week: 0 in progress, 0 interviewing, 0 offer(s). Response rate 0%. Keep the momentum going.	/analytics	weekly:2026-W33	\N	2026-08-10 09:01:43.561546+00	2026-08-10 09:01:43.561546+00
fd89443a-c459-4412-bdfa-02dcd039a69a	f769aa0b-a466-4da4-94a7-e0019363a53a	interview_soon	Interview soon — Machine Learning Engineer - College Graduate	Your interview is on Aug 13 at 2:24 AM. Time to prep.	/applications/96b6bc24-f3c5-498b-92dd-3dc732104005	interview_soon:96b6bc24-f3c5-498b-92dd-3dc732104005:2026-08-13	\N	2026-08-11 07:04:58.45779+00	2026-08-11 07:04:58.45779+00
\.


--
-- Data for Name: resume_profiles; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.resume_profiles (id, user_id, name, content, is_default, created_at, updated_at, tags, current_version, template, label, one_page) FROM stdin;
920c2bf5-3433-418f-bd17-a045aaa925fb	f769aa0b-a466-4da4-94a7-e0019363a53a	MHR_ML	{"awards": [], "basics": {"name": "Mohammad Hasnain Raza", "email": "razam@usc.edu", "links": [{"url": "https://linkedin.com/in/hasnainraza03", "label": "LinkedIn"}, {"url": "https://github.com/hasnainrazaa03", "label": "GitHub"}, {"url": "https://hasnainrazaa.vercel.app/", "label": "Website"}], "phone": "(213) 994-5086", "github": "https://github.com/hasnainrazaa03", "summary": null, "website": "https://hasnainrazaa.vercel.app/", "headline": null, "linkedin": "https://linkedin.com/in/hasnainraza03", "location": "Los Angeles, CA"}, "skills": [{"items": ["Python (Advanced)", "SQL", "R", "MATLAB", "Java", "C/C++", "JavaScript"], "category": "Languages"}, {"items": ["Classification", "Regression", "NLP", "Feature Engineering", "Model Training", "Evaluation", "Hyperparameter Tuning"], "category": "Machine Learning"}, {"items": ["PyTorch", "TensorFlow", "Hugging Face", "Scikit-learn", "Pandas", "NumPy"], "category": "F rameworks"}, {"items": ["Data Pipelines", "ETL", "Experimentation", "Statistical Analysis"], "category": "Data & Systems"}, {"items": ["Transformer Models", "BERT", "T5", "Prompt Engineering", "LLM Fine-tuning"], "category": "LLM & NLP"}, {"items": ["Docker", "A WS", "Git", "Tableau", "Model Quantization", "Model Monitoring"], "category": "T ools"}], "projects": [{"id": "c4fa061d7bb2", "url": null, "name": "Project Vimaan – AI V oice Command NLU System", "end_date": "Present", "highlights": ["Built a data-generation pipeline producing 30,000+ labeled voice commands for joint intent and slot classification, using schema-driven templates and LLM-based paraphrasing (Pegasus, FLAN-T5) to improve linguistic diversity and label consistency.", "Fine-tuned a DistilBERT model for joint intent classification and entity extraction, optimizing hyperparameters and label design, and applied INT8 quantization to reduce model size by 4x while maintaining 98% accuracy.", "Deployed the model within the X-Plane simulator using a plugin-based architecture with UDP-based IPC, enabling real-time inference with sub-500ms latency and integrating TTS feedback for closed-loop command validation."], "start_date": "2025-09", "description": "NLP/ML Pipeline with X-Plane Integration", "technologies": []}, {"id": "575af85bce7f", "url": null, "name": "USC Ledger – AI-Powered Financial Management Platform", "end_date": "Present", "highlights": ["Built a transactional data pipeline (React, Node.js, MongoDB) with a sequential reconciliation engine to ensure 100% consistency across concurrent updates, producing reliable structured data for downstream analytics and modeling.", "Engineered feature processing logic using fixed-precision arithmetic and 800ms debounced writes to handle high-frequency financial events, reducing API load and ensuring stable inputs for real-time inference.", "Integrated LLM-based analytics using the Google Gemini API, designing prompt templates and context summarization to detect spending anomalies and generate structured financial insights from transaction data."], "start_date": "2025-08", "description": "LLM Integration & Data Engineering", "technologies": []}], "education": [{"id": "756a53a95c4a", "gpa": "4.00", "degree": "Master of Science in Computer Science", "honors": [], "end_date": "2027-12", "location": "Los Angeles, CA", "coursework": ["Algorithms", "Database Systems", "Programming System Design", "Computer Networks", "Machine Learning"], "highlights": [], "start_date": "2025-08", "institution": "University of Southern California", "field_of_study": "Computer Science"}, {"id": "893feb75db31", "gpa": "3.86", "degree": "Bachelor of Engineering in Aerospace Engineering", "honors": ["Silver Medalist"], "end_date": "2022-07", "location": "Bengaluru, India", "coursework": ["Engineering Mathematics", "C Programming", "Computational Fluid Dynamics (CFD)", "Scientific Computing"], "highlights": [], "start_date": "2018-08", "institution": "R V College of Engineering", "field_of_study": "Aerospace Engineering"}], "experience": [{"id": "b313a1ac95f3", "title": "Technology Analyst", "company": "Deloitte", "end_date": "2024-11", "location": "Bengaluru, India", "highlights": ["Improved system throughput by 10x by automating manual onboarding with Pega PRPC workflows, implementing rule-based routing across tax, credit, and legal approval chains for customer creation and modification requests across 35+ countries.", "Built a REST API orchestration layer connecting Pega with Informatica MDM and downstream SAP systems, achieving sub-2s latency and ensuring consistent propagation of validated master records across distributed enterprise systems.", "Built LLM-assisted categorization workflows using few-shot prompting to classify customer data requests, achieving 92% agreement with human annotations through iterative refinement using human feedback.", "Implemented data preprocessing pipelines for LLM-based workflows, including automated quality checks, Z-score based outlier filtering, and PII masking, reducing data preparation effort by 30%."], "start_date": "2022-08", "technologies": []}, {"id": "3553d3cab1a7", "title": "Research Intern", "company": "Defence Research and Development Organisation (DRDO)", "end_date": "2022-08", "location": "Bengaluru, India", "highlights": ["Led a 4-member team to automate transient CFD simulations using PyFluent (k- ω SST, overset mesh), generating 1.2TB+ of aerodynamic data across multiple release conditions for downstream modeling and analysis.", "Engineered feature sets from pressure and force coefficients and applied multi-variate regression to model store separation trajectories, identifying key predictors influencing stability under varying flow conditions.", "Built data preprocessing and post-processing pipelines using Python and MATLAB, including Z-score based outlier filtering and time-series feature extraction, enabling reliable inputs for predictive modeling and downstream validation against sensor data."], "start_date": "2022-01", "technologies": []}, {"id": "961fac53e907", "title": "Founding Engineer", "company": "Prana.ai", "end_date": "2021-12", "location": "Remote", "highlights": ["Built end-to-end ML pipelines for 5M+ MRI/CT volumes, including normalization, patch extraction, and class-balanced sampling, enabling efficient training of 3D deep learning models on large-scale medical datasets.", "Designed and trained depthwise separable 3D CNNs for medical image segmentation, achieving < 0.8s inference latency through architecture optimization and efficient model deployment for real-time diagnostic use.", "Developed SO(3)-equivariant CNN-based super-resolution models using the e3nn library, leveraging rotation-equivariant convolutions to improve volumetric image quality by 35% over baseline methods."], "start_date": "2019-09", "technologies": []}], "publications": [], "section_order": ["summary", "education", "experience", "projects", "skills", "certifications", "awards", "publications"], "certifications": [], "schema_version": "1.0"}	t	2026-08-06 06:21:17.455744+00	2026-08-06 06:21:17.455744+00	["ML"]	1	modern	Imported résumé	t
\.


--
-- Data for Name: resume_versions; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.resume_versions (id, resume_profile_id, version, content, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: saved_cover_letters; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.saved_cover_letters (id, user_id, application_id, resume_profile_id, company, role, hiring_manager, tone, used_voice, paragraphs, job_text, guardrail_report, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.sessions (id, user_id, refresh_token_hash, user_agent, ip_address, last_used_at, expires_at, revoked_at, created_at, updated_at) FROM stdin;
a2afa5cf-8081-444e-9c32-12abb710ef43	f769aa0b-a466-4da4-94a7-e0019363a53a	fe400c79f32a40e4fda618a5c2e93fb2d54f4562aea8f7c0741f0a48a4ff96c4	curl/8.14.1	127.0.0.1	2026-08-06 06:26:03.845612+00	2026-08-20 06:26:03.845616+00	\N	2026-08-06 06:26:03.820954+00	2026-08-06 06:26:03.820954+00
c01a6eeb-8d6e-450b-95a4-1002b25bbaed	f769aa0b-a466-4da4-94a7-e0019363a53a	fedc619569f7cb4559aa086f4bae0a9d42f13b9d96f2d5d309679eb24919e6d4	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	192.168.65.1	2026-08-12 00:30:21.825847+00	2026-08-20 06:26:37.574988+00	\N	2026-08-06 06:26:37.544431+00	2026-08-12 00:30:21.818168+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.users (id, email, hashed_password, full_name, is_active, is_superuser, created_at, updated_at, is_verified, verified_at, theme, notification_prefs, encrypted_gemini_key, encrypted_anthropic_key, encrypted_openai_key, llm_provider, llm_model) FROM stdin;
f769aa0b-a466-4da4-94a7-e0019363a53a	hasnainrazaa03@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$jQKsw60veFHWFz3wXPm2pA$I4mkyykh+T1HpD82TJQ/wFHCASNihAugYtYRABIPo5M	Hasnain Raza	t	f	2026-08-06 06:21:17.455744+00	2026-08-06 06:21:17.455744+00	t	\N	dark	{"product_emails": true, "weekly_summary": true, "application_reminders": true}	\N	\N	\N	gemini	\N
\.


--
-- Data for Name: writing_profiles; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.writing_profiles (id, user_id, voice, analyzed_at, created_at, updated_at) FROM stdin;
516f965d-20b7-470e-b6ab-649189832852	f769aa0b-a466-4da4-94a7-e0019363a53a	\N	\N	2026-08-06 06:26:53.029504+00	2026-08-06 06:26:53.029504+00
\.


--
-- Data for Name: writing_samples; Type: TABLE DATA; Schema: public; Owner: hirecraft
--

COPY public.writing_samples (id, writing_profile_id, kind, title, content, created_at, updated_at) FROM stdin;
52e83bfe-129a-440d-96b2-b91ff577ac1b	516f965d-20b7-470e-b6ab-649189832852	COVER_LETTER	Qualcomm ML Cover Letter	Dear Hiring Manager,\n\nI am excited to apply for the Machine Learning Engineer position at Qualcomm. I am currently pursuing my MS in Computer Science at USC, where I focus on machine learning systems, distributed computing, and production AI. Across my work at Deloitte, Prana.ai, and personal projects, I have enjoyed solving problems that combine software engineering with machine learning.\n\nAt Deloitte, I built REST API orchestration layers connecting enterprise platforms across more than 35 countries while improving onboarding throughput by 10x. I also worked on LLM-assisted workflows that automated customer request categorization and reduced manual effort. At Prana.ai, I built data pipelines for large-scale medical imaging datasets and optimized deep learning models for real-time deployment. More recently, I have been building projects involving LLMs, data engineering, and distributed backend systems at USC.\n\nWhat excites me most about Qualcomm is the opportunity to work on efficient machine learning systems that move from research into production. I enjoy thinking about both model quality and the engineering required to deploy those models reliably at scale.\n\nThank you for your time and consideration. I would appreciate the opportunity to discuss how my background can contribute to your team.\n\nSincerely,\n\nMohammad Hasnain Raza	2026-08-09 03:59:13.420036+00	2026-08-09 03:59:13.420036+00
1af9c927-6258-4917-a84d-0b4184a84f25	516f965d-20b7-470e-b6ab-649189832852	EMAIL	Recruiter Follow-up	Hi Sarah,\n\nThank you again for taking the time to speak with me yesterday. I really enjoyed learning more about the team and the work you're doing around production machine learning systems.\n\nOur discussion reinforced my interest in the role, particularly the opportunity to work on large-scale backend infrastructure supporting ML models in production. I believe my experience building REST APIs, distributed data pipelines, and LLM-powered workflows would allow me to contribute quickly.\n\nPlease let me know if there's anything else I can provide during the interview process. I appreciate your time and look forward to hearing from you.\n\nBest,\nHasnain	2026-08-09 03:59:34.05738+00	2026-08-09 03:59:34.05738+00
66336d5c-7155-420c-9e54-c6850e478786	516f965d-20b7-470e-b6ab-649189832852	OTHER	Why I Enjoy Building ML Systems	The projects I enjoy most sit at the intersection of machine learning and software engineering. While training models is interesting, I find the engineering challenges around data pipelines, distributed systems, and deployment even more rewarding.\n\nOver the past few years I've worked on enterprise APIs, medical imaging pipelines, LLM-powered applications, and backend systems. Those experiences taught me that good machine learning products depend just as much on reliable engineering as they do on model accuracy. I enjoy designing systems that are scalable, maintainable, and easy to extend rather than simply optimizing benchmark performance.\n\nMy goal is to become an engineer who can build production-ready AI systems from end to end, combining strong backend engineering with practical machine learning.	2026-08-09 03:59:53.065456+00	2026-08-09 03:59:53.065456+00
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: application_artifacts application_artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.application_artifacts
    ADD CONSTRAINT application_artifacts_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: career_profiles career_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.career_profiles
    ADD CONSTRAINT career_profiles_pkey PRIMARY KEY (id);


--
-- Name: evidence_items evidence_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.evidence_items
    ADD CONSTRAINT evidence_items_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (key);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: llm_usage llm_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: resume_profiles resume_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_profiles
    ADD CONSTRAINT resume_profiles_pkey PRIMARY KEY (id);


--
-- Name: resume_versions resume_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_versions
    ADD CONSTRAINT resume_versions_pkey PRIMARY KEY (id);


--
-- Name: saved_cover_letters saved_cover_letters_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.saved_cover_letters
    ADD CONSTRAINT saved_cover_letters_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: notifications uq_notification_dedupe; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT uq_notification_dedupe UNIQUE (user_id, dedupe_key);


--
-- Name: resume_profiles uq_resume_profile_user_name; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_profiles
    ADD CONSTRAINT uq_resume_profile_user_name UNIQUE (user_id, name);


--
-- Name: resume_versions uq_resume_version_profile_version; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_versions
    ADD CONSTRAINT uq_resume_version_profile_version UNIQUE (resume_profile_id, version);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: writing_profiles writing_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.writing_profiles
    ADD CONSTRAINT writing_profiles_pkey PRIMARY KEY (id);


--
-- Name: writing_samples writing_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.writing_samples
    ADD CONSTRAINT writing_samples_pkey PRIMARY KEY (id);


--
-- Name: ix_application_artifacts_application_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_application_artifacts_application_id ON public.application_artifacts USING btree (application_id);


--
-- Name: ix_applications_celery_task_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_celery_task_id ON public.applications USING btree (celery_task_id);


--
-- Name: ix_applications_job_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_job_id ON public.applications USING btree (job_id);


--
-- Name: ix_applications_pipeline_status; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_pipeline_status ON public.applications USING btree (pipeline_status);


--
-- Name: ix_applications_resume_profile_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_resume_profile_id ON public.applications USING btree (resume_profile_id);


--
-- Name: ix_applications_tracker_status; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_tracker_status ON public.applications USING btree (tracker_status);


--
-- Name: ix_applications_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_applications_user_id ON public.applications USING btree (user_id);


--
-- Name: ix_auth_tokens_token_hash; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE UNIQUE INDEX ix_auth_tokens_token_hash ON public.auth_tokens USING btree (token_hash);


--
-- Name: ix_auth_tokens_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_auth_tokens_user_id ON public.auth_tokens USING btree (user_id);


--
-- Name: ix_career_profiles_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE UNIQUE INDEX ix_career_profiles_user_id ON public.career_profiles USING btree (user_id);


--
-- Name: ix_evidence_items_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_evidence_items_user_id ON public.evidence_items USING btree (user_id);


--
-- Name: ix_jobs_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_jobs_user_id ON public.jobs USING btree (user_id);


--
-- Name: ix_llm_usage_application_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_llm_usage_application_id ON public.llm_usage USING btree (application_id);


--
-- Name: ix_llm_usage_purpose; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_llm_usage_purpose ON public.llm_usage USING btree (purpose);


--
-- Name: ix_llm_usage_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_llm_usage_user_id ON public.llm_usage USING btree (user_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_resume_profiles_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_resume_profiles_user_id ON public.resume_profiles USING btree (user_id);


--
-- Name: ix_resume_versions_resume_profile_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_resume_versions_resume_profile_id ON public.resume_versions USING btree (resume_profile_id);


--
-- Name: ix_saved_cover_letters_application_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_saved_cover_letters_application_id ON public.saved_cover_letters USING btree (application_id);


--
-- Name: ix_saved_cover_letters_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_saved_cover_letters_user_id ON public.saved_cover_letters USING btree (user_id);


--
-- Name: ix_sessions_refresh_token_hash; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_sessions_refresh_token_hash ON public.sessions USING btree (refresh_token_hash);


--
-- Name: ix_sessions_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_sessions_user_id ON public.sessions USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_writing_profiles_user_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE UNIQUE INDEX ix_writing_profiles_user_id ON public.writing_profiles USING btree (user_id);


--
-- Name: ix_writing_samples_writing_profile_id; Type: INDEX; Schema: public; Owner: hirecraft
--

CREATE INDEX ix_writing_samples_writing_profile_id ON public.writing_samples USING btree (writing_profile_id);


--
-- Name: application_artifacts application_artifacts_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.application_artifacts
    ADD CONSTRAINT application_artifacts_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: applications applications_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: applications applications_resume_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_resume_profile_id_fkey FOREIGN KEY (resume_profile_id) REFERENCES public.resume_profiles(id) ON DELETE RESTRICT;


--
-- Name: applications applications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_tokens auth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: career_profiles career_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.career_profiles
    ADD CONSTRAINT career_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: evidence_items evidence_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.evidence_items
    ADD CONSTRAINT evidence_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: jobs jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: llm_usage llm_usage_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: llm_usage llm_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.llm_usage
    ADD CONSTRAINT llm_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: resume_profiles resume_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_profiles
    ADD CONSTRAINT resume_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: resume_versions resume_versions_resume_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.resume_versions
    ADD CONSTRAINT resume_versions_resume_profile_id_fkey FOREIGN KEY (resume_profile_id) REFERENCES public.resume_profiles(id) ON DELETE CASCADE;


--
-- Name: saved_cover_letters saved_cover_letters_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.saved_cover_letters
    ADD CONSTRAINT saved_cover_letters_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE SET NULL;


--
-- Name: saved_cover_letters saved_cover_letters_resume_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.saved_cover_letters
    ADD CONSTRAINT saved_cover_letters_resume_profile_id_fkey FOREIGN KEY (resume_profile_id) REFERENCES public.resume_profiles(id) ON DELETE SET NULL;


--
-- Name: saved_cover_letters saved_cover_letters_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.saved_cover_letters
    ADD CONSTRAINT saved_cover_letters_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: writing_profiles writing_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.writing_profiles
    ADD CONSTRAINT writing_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: writing_samples writing_samples_writing_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hirecraft
--

ALTER TABLE ONLY public.writing_samples
    ADD CONSTRAINT writing_samples_writing_profile_id_fkey FOREIGN KEY (writing_profile_id) REFERENCES public.writing_profiles(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict msrQfio6IoRWosJcydSqqyg11i8e5JqlphmXdesBJ7fI2Nat26hW3iervEbX5ik

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 3Lw0KUAytuphVNS6bQmPHByuD9fIh5NVMlQuv44SQpjwudCK90dFIiwEBn8574d

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 3Lw0KUAytuphVNS6bQmPHByuD9fIh5NVMlQuv44SQpjwudCK90dFIiwEBn8574d

--
-- PostgreSQL database cluster dump complete
--

